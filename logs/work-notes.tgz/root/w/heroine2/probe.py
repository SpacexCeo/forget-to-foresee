import bpy, sys
from mathutils import Vector
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath='/root/w/heroine2/iris_plain.glb')
for o in bpy.data.objects:
    if o.type=='MESH':
        vs=[o.matrix_world@v.co for v in o.data.vertices]
        mn=[min(v[i] for v in vs) for i in range(3)]; mx=[max(v[i] for v in vs) for i in range(3)]
        print(o.name, len(vs), [round(a,3) for a in mn],[round(a,3) for a in mx], [m.name for m in o.data.materials], 'keys', len(o.data.shape_keys.key_blocks) if o.data.shape_keys else 0, 'uv', [u.name for u in o.data.uv_layers], 'parent', o.parent.name if o.parent else None)
    else: print(o.name,o.type, tuple(round(a,3) for a in o.matrix_world.translation), o.parent.name if o.parent else None, o.parent_bone)
b=bpy.data.objects['base']
import collections
h=collections.Counter()
for v in b.data.vertices:
    w=b.matrix_world@v.co; h[round(w.z*10)/10]+=1
print('body z hist',sorted(h.items()))
rig=[o for o in bpy.data.objects if o.type=='ARMATURE'][0]
for bn in rig.data.bones: print('bone',bn.name, tuple(round(a,3) for a in (rig.matrix_world@bn.head_local)), tuple(round(a,3) for a in (rig.matrix_world@bn.tail_local)))
print('actions',[(a.name,a.frame_range[:]) for a in bpy.data.actions])
print('fps',bpy.context.scene.render.fps)
import numpy as np
for nm in ("base","sports_top","leggings"):
    o=bpy.data.objects[nm]; print(nm)
    for z0 in np.arange(0.75,1.5,0.05) if nm!="leggings" else np.arange(0.1,1.05,0.1):
        vs=[v.co for v in o.data.vertices if z0<=v.co.z<z0+0.05 and abs(v.co.x)<0.2]
        if vs: print("  z",round(z0,2),len(vs),"x",round(min(v.x for v in vs),3),round(max(v.x for v in vs),3),"y",round(min(v.y for v in vs),3),round(max(v.y for v in vs),3), "central", len([v for v in vs if abs(v.x)<0.1]))
print([k.name for k in bpy.data.objects["base"].data.shape_keys.key_blocks])
print("vg",[g.name for g in bpy.data.objects["hair_cap"].vertex_groups])
