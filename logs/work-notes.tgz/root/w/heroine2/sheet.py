from PIL import Image
a=[Image.open("view_%s.png"%n).convert("RGB") for n in ("front","side","back","q34")]
b=[Image.open("view_%s.png"%n).convert("RGB") for n in ("face","face34","hairback","lacing")]
W=Image.new("RGB",(640*4,1240+620),(255,255,255))
for i,x in enumerate(a): W.paste(x,(640*i,0))
for i,x in enumerate(b): W.paste(x,(640*i+10,1240))
W.save("preview.jpg",quality=88)
W.crop((0,0,2560,1240)).resize((1600,775)).save("p1.jpg",quality=85); W.crop((0,1240,2560,1860)).resize((1600,388)).save("p2.jpg",quality=88)
