"""Second playable heroine (agent_heroine2), built on Iris's skeleton so every Iris clip plays on her.

    blender -b -P art/agents/heroine2/build_heroine2.py -- <work dir>

Design authority: the owner's storyboards in docs/art/heroine2/refs/ (master turnaround, head and face, hair
construction, costume construction, accessories, colour and materials).

Inputs in <work dir>: iris_plain.glb and tex/*.png (decode.mjs from the shipped agent_iris.glb) and
agents/_raw/iris_hero/iris_body.blend (build_iris_hero.py -- body: the full body under Iris's costume).
Outputs in <work dir>/out: heroine2.blend (editable scene), h2_blender.glb (meshes + weights; graft.mjs puts
them on Iris's exact skeleton and clips) and view_{front,back,side,q34}.png.
"""
import bpy, bmesh, math, os, sys
import numpy as np
from mathutils import Vector, Matrix, kdtree
from mathutils.bvhtree import BVHTree

W = sys.argv[sys.argv.index("--") + 1]
OUT = os.path.join(W, "out"); os.makedirs(OUT, exist_ok=True)
V = Vector
N = "agent_heroine2"
ARM = [f"{b}_{s}" for b in ("upperarm", "forearm", "hand", "thumb", "index", "fingers", "prop") for s in "LR"]
OUTLINE = 0.0016            # the thin ink line: an inverted hull this far off the surface (m)

# ---------------------------------------------------------------- scene
bpy.ops.wm.open_mainfile(filepath=os.path.join(W, "agents/_raw/iris_hero/iris_body.blend"))
for o in list(bpy.data.objects):
    o.name = "src_" + o.name
bpy.ops.import_scene.gltf(filepath=os.path.join(W, "iris_plain.glb"))
rig = bpy.data.objects["rig"]
head = next(o for o in bpy.data.objects if o.type == "MESH" and not o.name.startswith("src_") and o.data.shape_keys)
print("H2 objects", [(o.name, o.type) for o in bpy.data.objects])
body = bpy.data.objects["src_body"]
cap = bpy.data.objects["hair_cap"]
col = bpy.data.objects["agent_iris_col"]
keep = {rig, head, body, cap, col, bpy.data.objects["eyeball_L"], bpy.data.objects["eyeball_R"]}
for o in list(bpy.data.objects):
    if o not in keep:
        bpy.data.objects.remove(o)
sc = bpy.context.scene
for o in keep:
    if o.name not in sc.collection.all_objects:
        sc.collection.objects.link(o)


def active(o):
    bpy.ops.object.select_all(action="DESELECT"); o.select_set(True); bpy.context.view_layer.objects.active = o


def bind(o, bone=None):
    o.parent = rig; o.matrix_world = Matrix.Identity(4)
    for m in list(o.modifiers):
        o.modifiers.remove(m)
    o.modifiers.new("Armature", "ARMATURE").object = rig
    if bone:
        o.vertex_groups.new(name=bone).add(range(len(o.data.vertices)), 1.0, "REPLACE")
    for p in o.data.polygons:
        p.use_smooth = True


active(body)
if body.data.shape_keys:
    bpy.ops.object.shape_key_remove(all=True, apply_mix=False)
bm = bmesh.new(); bm.from_mesh(body.data)          # a smooth bust under the fabric (the bodice follows this surface)
bust = [v for v in bm.verts if 1.19 < v.co.z < 1.35 and v.co.y < -0.085 and abs(v.co.x) < 0.15]
for sx in (1, -1):                # no pointed tips: cap each side 16 mm behind its foremost point, then round it
    side = [v for v in bust if v.co.x * sx > 0]
    cap_y = min(v.co.y for v in side) + 0.016
    for v in side:
        v.co.y = max(v.co.y, cap_y)
for _ in range(18):
    bmesh.ops.smooth_vert(bm, verts=bust, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)
bm.to_mesh(body.data); bm.free()
kd = kdtree.KDTree(len(body.data.vertices))
for v in body.data.vertices:
    kd.insert(v.co, v.index)
kd.balance()
err = [kd.find(v.co)[2] for v in head.data.vertices if v.co.z > 1.5][::20]
print("H2 head/body alignment: max", round(max(err), 5), "mean", round(sum(err) / len(err), 5))

# ---------------------------------------------------------------- textures
def load(name):
    img = bpy.data.images.load(os.path.join(W, "tex", "agent_iris_" + name + ".png"))
    a = np.empty(img.size[0] * img.size[1] * 4, np.float32); img.pixels.foreach_get(a)
    return img, a.reshape(img.size[1], img.size[0], 4)


def store(img, a, name, data=False):
    img.pixels.foreach_set(a.ravel()); img.name = name
    img.filepath_raw = os.path.join(OUT, name + ".png"); img.file_format = "PNG"; img.save()
    if data:
        img.colorspace_settings.name = "Non-Color"
    return img


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)


sk_img, sk = load("skin_basecolor"); sn_img, sn = load("normal_skin"); so_img, so = load("skin_orm")
empty = sk[..., :3].max(axis=2) < 0.05
tone = np.median(sk[..., :3][(sk[..., 0] > 0.55) & ~empty], axis=0)
sk[empty, :3] = tone; sk[..., 3] = 1
PALE = np.array((0.955, 0.845, 0.800), np.float32)            # the storyboard's pale skin
sk[..., :3] = np.clip(sk[..., :3] * (PALE / tone), 0, 1)
if sn.shape == sk.shape:
    sn[empty, :3] = (0.5, 0.5, 1.0)
sn[..., 3] = 1
if so.shape == sk.shape:
    so[empty, :3] = np.median(so[..., :3][~empty], axis=0)
so[..., 3] = 1
ST_TOP, ST_BAND = 0.715, 0.665        # lace-top stockings: top edge and the lower edge of the lace band (m)


def stocking_alpha(P):
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    th = np.arctan2(y + 0.016, np.abs(x) - 0.087)
    s = 0.0085; a = th * 0.075 / s; b = z / s
    n = np.minimum(np.abs(np.sin(math.pi * (a + b))), np.abs(np.sin(math.pi * (a - b))))
    lace = 0.62 + 0.36 * np.maximum(1 - smooth(0.0, 0.32, n), 1 - smooth(0.14, 0.3, np.hypot(a - np.floor(a) - 0.5, b - np.floor(b) - 0.5)))
    edge = ST_BAND - 0.007 * np.abs(np.sin(math.pi * a * 0.5))
    al = np.where(z > edge, lace, 0.60)
    al = np.where((z > ST_TOP - 0.004) | (np.abs(z - ST_BAND) < 0.0025), 0.95, al)
    return np.where(z > ST_TOP, 0.0, al)


def paint(obj, tex):
    me = obj.data; me.calc_loop_triangles()
    uv = np.array([l.uv[:] for l in me.uv_layers.active.data]); co = np.array([v.co[:] for v in me.vertices])
    H = tex.shape[0]; ink = np.array((0.045, 0.04, 0.05), np.float32); cnt = 0; src = tex.copy()
    for t in me.loop_triangles:
        P = co[list(t.vertices)]
        if P[:, 2].min() > ST_TOP + 0.002:
            continue
        U = uv[list(t.loops)] * H
        x0, x1 = max(0, int(U[:, 0].min()) - 1), min(H - 1, int(U[:, 0].max()) + 2)
        y0, y1 = max(0, int(U[:, 1].min()) - 1), min(H - 1, int(U[:, 1].max()) + 2)
        d = (U[1, 1] - U[2, 1]) * (U[0, 0] - U[2, 0]) + (U[2, 0] - U[1, 0]) * (U[0, 1] - U[2, 1])
        if x1 <= x0 or y1 <= y0 or abs(d) < 1e-9:
            continue
        X, Y = np.meshgrid(np.arange(x0, x1) + 0.5, np.arange(y0, y1) + 0.5)
        b0 = ((U[1, 1] - U[2, 1]) * (X - U[2, 0]) + (U[2, 0] - U[1, 0]) * (Y - U[2, 1])) / d
        b1 = ((U[2, 1] - U[0, 1]) * (X - U[2, 0]) + (U[0, 0] - U[2, 0]) * (Y - U[2, 1])) / d
        b2 = 1 - b0 - b1
        m = (b0 >= -0.04) & (b1 >= -0.04) & (b2 >= -0.04)
        if not m.any():
            continue
        Q = b0[m][:, None] * P[0] + b1[m][:, None] * P[1] + b2[m][:, None] * P[2]
        al = stocking_alpha(Q)[:, None]
        ys, xs = np.nonzero(m)
        tex[ys + y0, xs + x0, :3] = src[ys + y0, xs + x0, :3] * (1 - al) + ink * al
        cnt += 1
    print("H2 stocking triangles", cnt)


paint(body, sk)
sk_img = store(sk_img, sk, N + "_skin_basecolor"); sn_img = store(sn_img, sn, N + "_normal_skin", True); so_img = store(so_img, so, N + "_skin_orm", True)

ey_img, ey = load("eye_basecolor")                          # burgundy irises
r, g, b = ey[..., 0], ey[..., 1], ey[..., 2]
m = np.clip((g - r) / 0.035, 0, 1)[..., None]
lum = (0.3 * r + 0.6 * g + 0.1 * b)[..., None]
ey[..., :3] = ey[..., :3] * (1 - m) + np.clip(lum * np.array((1.35, 0.36, 0.42)), 0, 1) * m
ey_img = store(ey_img, ey, N + "_eye_basecolor")
en_img, en = load("normal_eye"); en_img = store(en_img, en, N + "_normal_eye", True)
eo_img, eo = load("eye_orm"); eo_img = store(eo_img, eo, N + "_eye_orm", True)
mo_img, mo = load("mouth_basecolor"); mo_img = store(mo_img, mo, N + "_mouth_basecolor")

CHARCOAL = np.array((0.215, 0.215, 0.265), np.float32); COBALT = np.array((0.08, 0.17, 0.80), np.float32)
ha_img, ha = load("hair_basecolor")
Hh, Wh = ha.shape[:2]
hl = np.clip(ha[..., :3].mean(axis=2) / 0.50, 0.25, 1.35)[..., None] ** 1.1
strands = hl[Hh - 512:, :512].copy()                        # a patch of the opaque strand field (top of the atlas)
ha[..., :3] = np.clip(hl * CHARCOAL, 0, 1)
ha_img = store(ha_img, ha, N + "_hair_basecolor")
hn_img, hn = load("normal_hair"); hn_img = store(hn_img, hn, N + "_normal_hair", True)
ho_img, ho = load("hair_orm"); ho_img = store(ho_img, ho, N + "_hair_orm", True)
# the constructed hair (fringe, locks, bun): one strip, charcoal at v = 1 running into cobalt at v = 0
t = smooth(0.28, 0.62, (np.arange(512) + 0.5) / 512)[:, None, None]
g2 = np.ones((512, 512, 4), np.float32)
g2[..., :3] = np.clip(strands * (CHARCOAL * t + COBALT * (1 - t)), 0, 1)
h2_img = store(bpy.data.images.new(N + "_hair2_basecolor", 512, 512, alpha=False), g2, N + "_hair2_basecolor")

# ---------------------------------------------------------------- materials
def mat(name, base=None, orm=None, nrm=None, color=(1, 1, 1), rough=0.6, metal=0.0, alpha=False, emis=None, double=True):
    m = bpy.data.materials.new(name); m.use_nodes = True; nt = m.node_tree
    p = nt.nodes["Principled BSDF"]
    p.inputs["Base Color"].default_value = (*color, 1); p.inputs["Roughness"].default_value = rough
    p.inputs["Metallic"].default_value = metal
    if base:
        t_ = nt.nodes.new("ShaderNodeTexImage"); t_.image = base
        nt.links.new(t_.outputs["Color"], p.inputs["Base Color"])
        if alpha:
            nt.links.new(t_.outputs["Alpha"], p.inputs["Alpha"])
    if orm:
        t_ = nt.nodes.new("ShaderNodeTexImage"); t_.image = orm
        s = nt.nodes.new("ShaderNodeSeparateColor")
        nt.links.new(t_.outputs["Color"], s.inputs[0])
        nt.links.new(s.outputs[1], p.inputs["Roughness"]); nt.links.new(s.outputs[2], p.inputs["Metallic"])
    if nrm:
        t_ = nt.nodes.new("ShaderNodeTexImage"); t_.image = nrm
        nm = nt.nodes.new("ShaderNodeNormalMap")
        nt.links.new(t_.outputs["Color"], nm.inputs["Color"]); nt.links.new(nm.outputs["Normal"], p.inputs["Normal"])
    if emis:
        p.inputs["Emission Color"].default_value = (*emis, 1); p.inputs["Emission Strength"].default_value = 1.0
    m.use_backface_culling = not double
    return m


M_SKIN = mat("M_H2_Skin", sk_img, so_img, sn_img)
M_EYE = mat("M_H2_Eye", ey_img, eo_img, en_img)
M_MOUTH = mat("M_H2_Mouth", mo_img, rough=0.32)
M_HAIR = mat("M_H2_Hair", ha_img, ho_img, hn_img, alpha=True)
M_CAP = mat("M_H2_CapHair", ha_img, ho_img, hn_img, alpha=True, double=False)
M_LOCK = mat("M_H2_HairSolid", h2_img, rough=0.42)
M_DRESS = mat("M_H2_Dress", color=(0.014, 0.014, 0.019), rough=0.58)
M_SHOE = mat("M_H2_Shoe", color=(0.012, 0.012, 0.015), rough=0.32)
M_RIBBON = mat("M_H2_Ribbon", color=(0.33, 0.03, 0.045), rough=0.45)
M_ENAMEL = mat("M_H2_Enamel", color=(0.02, 0.28, 1.0), rough=0.18, emis=(0.0, 0.07, 0.35))
M_DARK = mat("M_H2_DarkMetal", color=(0.02, 0.02, 0.035), rough=0.35, metal=0.4)
M_GOLD = mat("M_H2_Gold", color=(0.78, 0.62, 0.36), rough=0.3, metal=1.0)
M_PEARL = mat("M_H2_Pearl", color=(0.92, 0.9, 0.86), rough=0.2)
M_LINE = mat("M_H2_Outline", color=(0.0, 0.0, 0.0), rough=1.0, double=False)
M_LINE.use_backface_culling = True


def set_mats(o, *ms):
    o.data.materials.clear()
    for m_ in ms:
        o.data.materials.append(m_)


set_mats(head, M_SKIN, M_HAIR, M_MOUTH)
set_mats(body, M_SKIN)
set_mats(cap, M_CAP)
for s in "LR":
    set_mats(bpy.data.objects["eyeball_" + s], M_EYE)

# ---------------------------------------------------------------- helpers
def weights(o):
    names = [g_.name for g_ in o.vertex_groups]
    return [{names[g_.group]: g_.weight for g_ in v.groups} for v in o.data.vertices]


BW = weights(body)
BCO = [v.co.copy() for v in body.data.vertices]
armw = [sum(w.get(b_, 0) for b_ in ARM) for w in BW]
body_bvh = BVHTree.FromObject(body, bpy.context.evaluated_depsgraph_get())


def dup(src, name):
    o = src.copy(); o.data = src.data.copy(); o.name = name; sc.collection.objects.link(o); return o


def cut(o, pred):
    bm = bmesh.new(); bm.from_mesh(o.data)
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if pred(v)], context="VERTS")
    bm.to_mesh(o.data); bm.free()


def push_out(bm, d):
    for v in bm.verts:
        loc, nrm, _i, _d = body_bvh.find_nearest(v.co)
        if loc is not None and (v.co - loc).dot(nrm) < d:
            v.co = loc + nrm * d


def knn_weights(o, bones, k=8, alias=None):
    """Skin a constructed mesh from the nearest body vertices, restricted to `bones`."""
    alias = alias or {}
    wa = np.zeros((len(o.data.vertices), len(bones)))
    for v in o.data.vertices:
        for co, idx, dist in kd.find_n(v.co, k):
            for bn, w in BW[idx].items():
                bn = alias.get(bn, bn)
                if bn in bones:
                    wa[v.index, bones.index(bn)] += w / (dist + 0.01)
    wa[:, 0] += 1e-6
    return wa


def set_weights(o, bones, wa):
    wa = wa / wa.sum(axis=1, keepdims=True)
    for bi, bn in enumerate(bones):
        g_ = o.vertex_groups.new(name=bn)
        for i in np.nonzero(wa[:, bi] > 0.004)[0]:
            g_.add([int(i)], float(wa[i, bi]), "REPLACE")


def sweep(bm, uvl, pts, ws, hs, hints, sides=6, u=(0.0, 0.1), vs=None, mi=0, caps=True):
    n = len(pts); rings = []
    vs = vs or [0.95 - 0.4 * i / (n - 1) for i in range(n)]
    for i, p in enumerate(pts):
        t_ = (pts[min(i + 1, n - 1)] - pts[max(i - 1, 0)]).normalized()
        s = t_.cross(hints[i]).normalized(); nn = s.cross(t_).normalized()
        rings.append([bm.verts.new(p + s * ws[i] * math.cos(2 * math.pi * a / sides) + nn * hs[i] * math.sin(2 * math.pi * a / sides)) for a in range(sides)])
    for i in range(n - 1):
        for a in range(sides):
            f = bm.faces.new((rings[i][a], rings[i][(a + 1) % sides], rings[i + 1][(a + 1) % sides], rings[i + 1][a]))
            f.material_index = mi
            for l, (ii, aa) in zip(f.loops, ((i, a), (i, a + 1), (i + 1, a + 1), (i + 1, a))):
                l[uvl].uv = (u[0] + (u[1] - u[0]) * aa / sides, vs[ii])
    if caps:
        for ring, vv in ((rings[0], vs[0]), (rings[-1], vs[-1])):
            try:
                f = bm.faces.new(ring); f.material_index = mi
                for l in f.loops:
                    l[uvl].uv = (u[0], vv)
            except ValueError:
                pass


def blob(bm, uvl, c, ex, ey_, ez, uv=(0.3, 0.9), mi=0, vfn=None, seg=12):
    M = Matrix.Translation(c) @ Matrix((ex, ey_, ez)).transposed().to_4x4()
    r_ = bmesh.ops.create_uvsphere(bm, u_segments=seg, v_segments=max(6, seg // 2), radius=1.0, matrix=M)
    fs = {f for v in r_["verts"] for f in v.link_faces}
    for f in fs:
        f.material_index = mi
        for l in f.loops:
            l[uvl].uv = (uv[0] + 0.05 * math.atan2((l.vert.co - c).dot(ex.normalized()), (l.vert.co - c).dot(ey_.normalized())) / math.pi, vfn(l.vert.co) if vfn else uv[1])


def obj_from(bm, name, bone, *ms):
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    o = bpy.data.objects.new(name, me); sc.collection.objects.link(o)
    set_mats(o, *ms); bind(o, bone); return o


def add_outline(o, d=OUTLINE, only_slot=None, pred=None):
    """Thin ink line: the surface again, pushed out along its normals with flipped faces (drawn single-sided)."""
    o.data.materials.append(M_LINE); slot = len(o.data.materials) - 1
    bm = bmesh.new(); bm.from_mesh(o.data); bm.normal_update()
    faces = [f for f in bm.faces if (only_slot is None or f.material_index == only_slot) and (pred is None or pred(f.calc_center_median()))]
    r_ = bmesh.ops.duplicate(bm, geom=faces)
    nf = [e for e in r_["geom"] if isinstance(e, bmesh.types.BMFace)]
    nv = [e for e in r_["geom"] if isinstance(e, bmesh.types.BMVert)]
    shapes = list(bm.verts.layers.shape.values())
    for v in nv:
        off = v.normal * d
        v.co += off
        for sl in shapes:
            v[sl] = v[sl] + off
    for f in nf:
        f.material_index = slot
    bmesh.ops.reverse_faces(bm, faces=nf)
    bm.to_mesh(o.data); bm.free()


def smooth_boundary(bm, iters=8):
    """Evens the stair-steps a vertex cut leaves along an open edge."""
    for _ in range(iters):
        new = {}
        for v in bm.verts:
            if v.is_boundary:
                nb_ = [e.other_vert(v) for e in v.link_edges if e.is_boundary]
                if len(nb_) == 2:
                    new[v] = v.co * 0.5 + (nb_[0].co + nb_[1].co) * 0.25
        for v, c_ in new.items():
            v.co = c_


# ---------------------------------------------------------------- gown: bodice (a shell pulled off the body)
def xlim(z):                      # the halter's armhole line: from under the arm up to the collar
    return 0.155 + (0.052 - 0.155) * min(1, max(0, (z - 1.34) / 0.115))


Z_COLLAR = 1.455
BACK_V = (1.105, 0.27)            # the open back: apex height at the spine and its rise to the armholes


def back_open(p, k=0.0):
    return p.y > -0.012 and p.z > BACK_V[0] + k + abs(p.x) / 0.15 * BACK_V[1]


def in_bodice(p, aw):
    return aw < 0.35 and 0.90 < p.z < Z_COLLAR + 0.012 and (abs(p.x) < xlim(p.z) or p.z < 1.34) and not back_open(p)


bodice = dup(body, "gown_bodice")
bm = bmesh.new(); bm.from_mesh(bodice.data)
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not (armw[v.index] < 0.35 and 0.90 < v.co.z < 1.535)], context="VERTS")
bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not in_bodice(v.co, 0.0)], context="VERTS")
smooth_boundary(bm)
bm.normal_update()
for v in bm.verts:
    v.co += v.normal * 0.006
inner = [v for v in bm.verts if not v.is_boundary]
bmesh.ops.smooth_vert(bm, verts=inner, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)
chest = [v for v in inner if 1.15 < v.co.z < 1.38 and v.co.y < -0.03]
for _ in range(45):               # the fabric spans the bust instead of following it
    bmesh.ops.smooth_vert(bm, verts=chest, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)
for _ in range(2):
    push_out(bm, 0.005)
edge = [v.co.copy() for v in bm.verts if v.is_boundary]
bm.to_mesh(bodice.data); bm.free()
set_mats(bodice, M_DRESS); bind(bodice)

# the collar: a clean standing band round the neck
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
NC = 40; crow = []
for z in (1.446, 1.468, 1.492, 1.516, 1.534):
    ring = []
    for k in range(NC):
        th = 2 * math.pi * k / NC; d = V((math.cos(th), math.sin(th), 0)); c_ = V((0, 0.002, z))
        h = body_bvh.ray_cast(c_ + d * 0.3, -d)
        r_ = min((h[0] - c_).length, 0.074) if h[0] is not None else 0.055
        ring.append(r_)
    ring = [(ring[k - 1] + 2 * ring[k] + ring[(k + 1) % NC]) / 4 for k in range(NC)]
    crow.append([bm.verts.new(V((0, 0.002, z)) + V((math.cos(2 * math.pi * k / NC), math.sin(2 * math.pi * k / NC), 0)) * (ring[k] + 0.0085)) for k in range(NC)])
for j in range(4):
    for k in range(NC):
        bm.faces.new((crow[j][k], crow[j][(k + 1) % NC], crow[j + 1][(k + 1) % NC], crow[j + 1][k]))
collar = obj_from(bm, "gown_collar", None, M_DRESS)
CB = ["neck", "chest", "head", "shoulder_L", "shoulder_R"]
set_weights(collar, CB, knn_weights(collar, CB, k=6))
ekd = kdtree.KDTree(len(edge))
for i, p in enumerate(edge):
    ekd.insert(p, i)
ekd.balance()

# ---------------------------------------------------------------- gown: floor-length skirt with the laced slit on her left
def hull(pts):
    pts = sorted(set(pts))
    def half(ps):
        h = []
        for p in ps:
            while len(h) >= 2 and (h[-1][0] - h[-2][0]) * (p[1] - h[-2][1]) - (h[-1][1] - h[-2][1]) * (p[0] - h[-2][0]) <= 0:
                h.pop()
            h.append(p)
        return h
    lo, up = half(pts), half(pts[::-1])
    return lo[:-1] + up[:-1]


def radial(h, c, d):
    best = 0.0
    for i in range(len(h)):
        a, b_ = h[i], h[(i + 1) % len(h)]
        ex, ey_ = b_[0] - a[0], b_[1] - a[1]
        den = d[0] * ey_ - d[1] * ex
        if abs(den) < 1e-12:
            continue
        t_ = ((a[0] - c[0]) * ey_ - (a[1] - c[1]) * ex) / den
        s = ((a[0] - c[0]) * d[1] - (a[1] - c[1]) * d[0]) / den
        if t_ > 0 and -1e-6 <= s <= 1 + 1e-6:
            best = max(best, t_)
    return best


Z_TOP, Z_HEM, NU, NV = 1.045, 0.012, 96, 46
TH_SLIT = math.radians(-58)       # the slit: front of her left thigh
torso = [p for p, a in zip(BCO, armw) if a < 0.2 and abs(p.x) < 0.23]


def slit_half(z):                 # half-width of the opening (rad): a teardrop under the hip, then widening to the hem
    return math.radians(13) * float(smooth(0.965, 0.80, z)) + math.radians(9) * max(0.0, 0.80 - z) / 0.8


NA = 180
zs = [Z_TOP + (Z_HEM - Z_TOP) * j / (NV - 1) for j in range(NV)]
C0 = None; RR = []
for z in zs:
    win, sl = 0.016, []
    while len(sl) < 12:           # the leg loops are sparse: widen the slab until it holds an outline
        sl = [(p.x, p.y) for p in torso if abs(p.z - max(z, 0.10)) < win]; win *= 1.5
    h = hull(sl)
    C0 = C0 or (0.0, sum(q[1] for q in h) / len(h))
    RR.append([radial(h, C0, (math.cos(2 * math.pi * k / NA), math.sin(2 * math.pi * k / NA))) for k in range(NA)])
RR = np.array(RR)
for j in range(1, NV):            # fitted over the hips; never pulls in sharply below them
    RR[j] = np.maximum(RR[j], RR[j - 1] - 0.003)
for _ in range(4):
    RR[1:-1] = (RR[:-2] + 2 * RR[1:-1] + RR[2:]) / 4
    RR = (np.roll(RR, 1, axis=1) + 2 * RR + np.roll(RR, -1, axis=1)) / 4
for j, z in enumerate(zs):
    RR[j] += 0.0075 + 0.006 * float(smooth(1.0, 0.90, z)) + 0.115 * max(0.0, (0.64 - z) / 0.63) ** 1.7


def skirt_pt(th, z, out=0.0):
    fj = min(NV - 1.001, max(0.0, (Z_TOP - z) / (Z_TOP - Z_HEM) * (NV - 1))); j = int(fj); fj -= j
    fk = (th % (2 * math.pi)) / (2 * math.pi) * NA; k = int(fk) % NA; fk -= int(fk)
    r_ = (RR[j][k] * (1 - fk) + RR[j][(k + 1) % NA] * fk) * (1 - fj) + (RR[j + 1][k] * (1 - fk) + RR[j + 1][(k + 1) % NA] * fk) * fj
    r_ = r_ * (1 + 0.045 * max(0.0, (0.64 - z) / 0.63) * math.sin(11 * th + 0.6)) + out
    return V((C0[0] + r_ * math.cos(th), C0[1] + r_ * math.sin(th), z))


bm = bmesh.new()
vs_ = []
for z in zs:                      # an open strip round the body: its two ends are the slit's edges
    hw = max(slit_half(z), math.radians(0.2))
    vs_.append([bm.verts.new(skirt_pt(TH_SLIT + hw + (2 * math.pi - 2 * hw) * k / NU, z)) for k in range(NU + 1)])
for j in range(NV - 1):
    for k in range(NU):
        bm.faces.new((vs_[j][k], vs_[j + 1][k], vs_[j + 1][k + 1], vs_[j][k + 1]))
for v in bm.verts:
    loc, nrm, _i, _d = body_bvh.find_nearest(v.co)
    if loc is not None and (v.co - loc).dot(nrm) < 0.0085 and (v.co - loc).length < 0.05:
        v.co = loc + nrm * 0.0085
me = bpy.data.meshes.new("gown_skirt"); bm.to_mesh(me); bm.free()
skirt = bpy.data.objects.new("gown_skirt", me); sc.collection.objects.link(skirt)
SK = ["pelvis", "spine", "thigh_L", "thigh_R", "shin_L", "shin_R"]
FOOT = {f"{b_}_{s}": "shin_" + s for b_ in ("foot", "toe") for s in "LR"}
wa = knn_weights(skirt, SK, k=10, alias=FOOT)
skd = kdtree.KDTree(len(skirt.data.vertices))
for v in skirt.data.vertices:
    skd.insert(v.co, v.index)
skd.balance()
for _ in range(3):                # soften the hand-over between the two legs and down the cloth
    wa = np.array([np.mean([wa[i] for _c, i, _d in skd.find_n(v.co, 9)], axis=0) for v in skirt.data.vertices])
set_weights(skirt, SK, wa)
set_mats(skirt, M_DRESS); bind(skirt)


# lacing: a cord crossing the opening eight times, ending in a bow with two long tails
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
LZ = [0.945 - 0.021 * i for i in range(9)]
for sgn in (1, -1):
    pts = []
    for i, z in enumerate(LZ):
        side = sgn * (1 if i % 2 == 0 else -1)
        pts.append(skirt_pt(TH_SLIT + side * (slit_half(z) + math.radians(1.2)), z, 0.004))
    fine = [pts[i].lerp(pts[i + 1], q / 5) for i in range(len(pts) - 1) for q in range(5)] + [pts[-1]]
    sweep(bm, uvl, fine, [0.0021] * len(fine), [0.0021] * len(fine), [V((math.cos(TH_SLIT), math.sin(TH_SLIT), 0))] * len(fine), sides=5)
kn = skirt_pt(TH_SLIT, LZ[-1] - 0.004, 0.006); od = V((math.cos(TH_SLIT), math.sin(TH_SLIT), 0)); td = V((0, 0, 1)).cross(od).normalized()
blob(bm, uvl, kn, td * 0.005, V((0, 0, 0.004)), od * 0.004, seg=8)
for sgn in (1, -1):
    loop = [kn + td * sgn * (0.016 * math.sin(a_)) + V((0, 0, -0.030 * (1 - math.cos(a_)) / 2 - 0.004 * math.sin(a_))) + od * 0.002 for a_ in [math.pi * 2 * q / 16 for q in range(17)]]
    sweep(bm, uvl, loop, [0.0019] * 17, [0.0019] * 17, [od] * 17, sides=5)
    tail = [kn + td * sgn * (0.003 + 0.004 * q / 9) + V((0, 0, -0.012 * q)) + od * (0.002 + 0.0005 * q) for q in range(10)]
    sweep(bm, uvl, tail, [0.0019] * 10, [0.0019] * 10, [od] * 10, sides=5)
lacing = obj_from(bm, "gown_lacing", None, M_DRESS)
LB = ["pelvis", "thigh_L", "spine"]
set_weights(lacing, LB, knn_weights(lacing, LB, k=6))

# ---------------------------------------------------------------- closed-toe shoes (a shell over the foot)
shoe = dup(body, "shoes")
bm = bmesh.new(); bm.from_mesh(shoe.data)
bmesh.ops.delete(bm, geom=[v for v in bm.verts if not (v.co.z < 0.078 and abs(v.co.x) < 0.2 and armw[v.index] < 0.1)], context="VERTS")
bm.normal_update()
for v in bm.verts:
    v.co += v.normal * (0.007 + 0.006 * float(smooth(-0.10, -0.16, v.co.y)))
toe = [v for v in bm.verts if v.co.y < -0.085 and not v.is_boundary]
for _ in range(150):               # one smooth toe box instead of five toes
    bmesh.ops.smooth_vert(bm, verts=toe, factor=0.5, use_axis_x=True, use_axis_y=True, use_axis_z=True)
push_out(bm, 0.004)
for v in bm.verts:
    v.co.z = max(v.co.z, 0.0)
bm.to_mesh(shoe.data); bm.free(); set_mats(shoe, M_SHOE); bind(shoe)

# ---------------------------------------------------------------- burgundy wrist ribbons (both wrists, long tails)
bm_bow = bmesh.new(); uvl = bm_bow.loops.layers.uv.new("UVMap")
bands = []
for s, sx in (("L", 1), ("R", -1)):
    A_, B_ = V((0.207 * sx, -0.019, 1.15)), V((0.261 * sx, -0.042, 0.932)); AB = B_ - A_
    tp = lambda p: (p - A_).dot(AB) / AB.length_squared
    band = dup(body, "ribbon_wrap_" + s)
    bm = bmesh.new(); bm.from_mesh(band.data)
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if not (v.co.x * sx > 0.1 and armw[v.index] > 0.5 and 0.80 < tp(v.co) < 0.945)], context="VERTS")
    bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=1, use_grid_fill=True)
    bm.normal_update(); rmax = 0.0
    for v in bm.verts:
        t_ = tp(v.co)
        v.co += v.normal * (0.0035 + 0.0012 * math.sin((t_ - 0.80) / 0.145 * math.pi * 6) ** 2)      # the wraps overlap
        rmax = max(rmax, (v.co - (A_ + AB * t_)).length)
    bm.to_mesh(band.data); bm.free(); set_mats(band, M_RIBBON); bind(band); bands.append(band)
    axis = AB.normalized(); out = V((sx, -0.15, 0)); rad = (out - axis * out.dot(axis)).normalized(); tan = axis.cross(rad).normalized()
    kc = A_ + AB * 0.87 + rad * (rmax * 0.80 + 0.004)
    blob(bm_bow, uvl, kc, tan * 0.007, axis * 0.007, rad * 0.004, seg=8)
    for q, sg in enumerate((1, -1)):
        L = 0.21 - 0.04 * q
        tail = [kc + V((sg * (0.005 + 0.012 * (j / 11)), 0.004 * sg, -L * j / 11)) + rad * (0.003 + 0.004 * math.sin(j / 11 * math.pi)) for j in range(12)]
        sweep(bm_bow, uvl, tail, [0.0085] * 11 + [0.004], [0.0011] * 12, [V((0, -1, 0))] * 12, sides=4)
bm_bow.verts.ensure_lookup_table()
sides_ = [1 if v.co.x > 0 else -1 for v in bm_bow.verts]
bow = obj_from(bm_bow, "ribbon_tails", None, M_RIBBON)
for s, sx in (("L", 1), ("R", -1)):
    bow.vertex_groups.new(name="forearm_" + s).add([i for i, q in enumerate(sides_) if q == sx], 1.0, "REPLACE")

# ---------------------------------------------------------------- hair
tw = weights(cap)
tailv = {i for i, w in enumerate(tw) if sum(w.get(f"tail_{k}", 0) for k in range(3)) > 0.3}
cut(cap, lambda v: v.index in tailv)
bind(cap)
dg = bpy.context.evaluated_depsgraph_get()
cap_bvh = BVHTree.FromObject(cap, dg); head_bvh = BVHTree.FromObject(head, dg)
HC = V((0.0, 0.015, 1.675))       # about the middle of the skull


def on_head(origin, toward=HC, out=0.0):
    d = (toward - origin).normalized()
    hits = [h for h in (cap_bvh.ray_cast(origin, d), head_bvh.ray_cast(origin, d)) if h[0] is not None]
    if not hits:
        return None, None
    h = min(hits, key=lambda h: h[3])
    n = h[1] if h[1].dot(d) < 0 else -h[1]
    return h[0] + n * out, n


def front_y(x, z, last=-0.09):
    ys = [h[0].y for h in (cap_bvh.ray_cast(V((x, -0.5, z)), V((0, 1, 0))), head_bvh.ray_cast(V((x, -0.5, z)), V((0, 1, 0)))) if h[0] is not None]
    return min(ys) if ys else last


# the braided updo: a large bun behind the crown, slightly to her right, cobalt on its underside
hit, _n = on_head(V((-0.02, 0.6, 1.70)), V((-0.02, 0.0, 1.70)))
hit = hit or V((-0.02, 0.10, 1.70))
nb = V((-0.12, 1, 0.10)).normalized()
BC = hit + nb * 0.035
e1 = nb.cross(V((0, 0, 1))).normalized(); e2 = e1.cross(nb).normalized()


def hv(p):                        # charcoal on top, cobalt underneath
    return float(0.93 - 0.80 * smooth(0.0, 0.055, (BC.z - 0.012) - p.z))


bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
blob(bm, uvl, BC, e1 * 0.074, e2 * 0.070, nb * 0.058, vfn=hv, seg=14)
for R, dep, tw_, sr, k0 in ((0.068, 0.004, 11, 0.0125, 0.0), (0.050, 0.034, 8, 0.0125, 0.3), (0.028, 0.052, 5, 0.012, 0.6)):
    for k in range(2):
        pts = []
        for i in range(73):
            ph = 2 * math.pi * i / 72
            rd = e1 * math.cos(ph) + e2 * math.sin(ph)
            a_ = tw_ * ph + math.pi * k + k0
            pts.append(BC + nb * dep + rd * (R + 0.008 * math.cos(a_)) + nb * (0.008 * math.sin(a_)))
        u0 = 0.1 + 0.37 * k + k0 * 0.2
        sweep(bm, uvl, pts, [sr] * 73, [sr] * 73, [nb] * 73, sides=5, u=(u0, u0 + 0.07), vs=[hv(p) for p in pts], caps=False)
blob(bm, uvl, BC + nb * 0.060, e1 * 0.022, e2 * 0.022, nb * 0.014, vfn=hv)
# braids along both sides of the head into the bun
for sx in (1, -1):
    path = []
    for i in range(13):
        a_ = math.radians(8 + 74 * i / 12)
        o_ = HC + V((sx * math.cos(a_) * 0.4, math.sin(a_) * 0.4, 0.035 + 0.02 * i / 12))
        p, n = on_head(o_, HC + V((0, 0, 0.035 + 0.02 * i / 12)), 0.007)
        if p is not None:
            path.append((p, n))
    for k in range(2):
        pts, hints = [], []
        for i in range(len(path) * 4 - 3):
            a, f = divmod(i, 4); f /= 4
            p = path[a][0].lerp(path[min(a + 1, len(path) - 1)][0], f); n = path[a][1].lerp(path[min(a + 1, len(path) - 1)][1], f).normalized()
            ph = i * 0.62 + math.pi * k
            pts.append(p + V((0, 0, 1)) * 0.0065 * math.cos(ph) + n * 0.004 * math.sin(ph)); hints.append(n)
        sweep(bm, uvl, pts, [0.0085] * len(pts), [0.007] * len(pts), hints, sides=6, u=(0.55 + 0.2 * k, 0.62 + 0.2 * k), vs=[hv(p) for p in pts])
# cobalt under-layer: strands swept from the nape up into the bun
for i in range(9):
    x = -0.075 + 0.019 * i
    p0, n0 = on_head(V((x, 0.5, 1.575)), V((x * 0.6, 0.0, 1.60)), 0.006)
    if p0 is None:
        continue
    p2 = BC + e1 * (x * -0.9) - e2 * 0.050 + nb * 0.02
    p1 = (p0 + p2) / 2 + V((0, 0.035, -0.012))
    pts = [(1 - t_) ** 2 * p0 + 2 * t_ * (1 - t_) * p1 + t_ * t_ * p2 for t_ in [q / 9 for q in range(10)]]
    sweep(bm, uvl, pts, [0.013] * 10, [0.006] * 10, [V((0, 1, 0))] * 10, sides=6, u=(0.08 * i, 0.08 * i + 0.07), vs=[0.14] * 10)
bun = obj_from(bm, "hair_bun", "head", M_LOCK)

# the asymmetric fringe, the ahoge and two short wisps
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
FR = []                           # (end x, end z, width): her left is +x
for i in range(15):
    ex = 0.096 - 0.192 * i / 14
    ez = 1.664 + 0.007 * (i % 2) + 0.012 * (abs(ex) / 0.096) ** 2
    if i == 7:
        ez = 1.608                # the long strand between the eyes
    elif -0.058 < ex < -0.015:
        ez -= 0.026               # heavier over her right eye
    FR.append((ex, ez, 0.0165 if i != 7 else 0.011))
for i, (ex, ez, wd) in enumerate(FR):
    p0 = (0.016 + ex * 0.22, 1.762 - abs(ex) * 0.10)
    p1 = (ex * 0.95 + 0.006, 1.735 - abs(ex) * 0.22)
    pts, ws, hs, last = [], [], [], -0.09
    for j in range(16):
        t_ = j / 15
        x = (1 - t_) ** 2 * p0[0] + 2 * t_ * (1 - t_) * p1[0] + t_ * t_ * ex
        z = (1 - t_) ** 2 * p0[1] + 2 * t_ * (1 - t_) * p1[1] + t_ * t_ * ez
        last = front_y(x, z, last)
        pts.append(V((x, last - (0.005 + 0.006 * math.sin(math.pi * min(1.0, t_ * 1.15)) + 0.002 * (i % 2)), z)))
        ws.append(0.0012 + wd * (1 - t_ ** 2.2) * (0.55 + 0.45 * min(1, t_ * 4)))
        hs.append(0.0010 + 0.0028 * (1 - t_))
    sweep(bm, uvl, pts, ws, hs, [V((0, -1, 0))] * 16, sides=6, u=(0.062 * i, 0.062 * i + 0.06), vs=[0.95 - 0.22 * j / 15 for j in range(16)])
top, _n = on_head(V((0.012, -0.02, 2.2)), V((0.012, -0.02, 1.6)))
top = top or V((0.012, -0.02, 1.775))
ah = [top + V((0.004 + 0.030 * t_ * t_, -0.006 * t_, 0.052 * math.sin(t_ * 2.2) - 0.004)) for t_ in [q / 9 for q in range(10)]]
sweep(bm, uvl, ah, [0.0034 * (1 - 0.8 * q / 9) + 0.0006 for q in range(10)], [0.0018] * 10, [V((0, -1, 0))] * 10, sides=5, u=(0.4, 0.44), vs=[0.95] * 10)
fringe = obj_from(bm, "hair_fringe", "head", M_LOCK)

# face-framing locks in front of the ears, blue towards the tips; they ride Iris's hair spring bones
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
for sx in (1, -1):
    pts, ws, hs = [], [], []
    y0 = front_y(sx * 0.080, 1.70, -0.03) - 0.006
    for j in range(20):
        t_ = j / 19
        pts.append(V((sx * (0.081 + 0.006 * math.sin(t_ * math.pi) - 0.012 * t_ * t_), y0 - 0.018 * math.sin(t_ * math.pi * 0.9) - 0.010 * t_, 1.712 - (0.275 if sx > 0 else 0.300) * t_)))
        ws.append(0.0010 + 0.0075 * (1 - t_ ** 2)); hs.append(0.001 + 0.0026 * (1 - t_))
    sweep(bm, uvl, pts, ws, hs, [V((0, -1, 0))] * 20, sides=6, u=(0.2, 0.27), vs=[0.95 - 0.83 * smooth(0.35, 0.95, j / 19) for j in range(20)])
locks = obj_from(bm, "hair_locks", None, M_LOCK)
for s, sx in (("L", 1), ("R", -1)):
    g0 = locks.vertex_groups.new(name="head"); g1 = locks.vertex_groups.new(name=f"hair_{s}_0"); g2_ = locks.vertex_groups.new(name=f"hair_{s}_1")
    for v in locks.data.vertices:
        if v.co.x * sx <= 0:
            continue
        a = float(smooth(1.66, 1.58, v.co.z)); b_ = float(smooth(1.56, 1.47, v.co.z))
        for g_, w in ((g0, 1 - a), (g1, a * (1 - b_)), (g2_, a * b_)):
            if w > 0.004:
                g_.add([v.index], w, "REPLACE")

# ---------------------------------------------------------------- hairpiece (her right side): enamel butterfly, two dark flowers
def flower(bm, uvl, c, n, R, petals, mi_petal, mi_centre, layers=1):
    ax = n.cross(V((0, 0, 1))).normalized(); ay = n.cross(ax).normalized()
    for L in range(layers):
        for i in range(petals):
            a_ = 2 * math.pi * (i + 0.5 * L) / petals; rd = ax * math.cos(a_) + ay * math.sin(a_); tg = n.cross(rd)
            k = 1 - 0.3 * L
            blob(bm, uvl, c + rd * R * 0.55 * k + n * (0.0015 + 0.002 * L), rd * R * 0.5 * k, tg * R * 0.2, n * R * 0.07 + rd * R * 0.12, mi=mi_petal, seg=8)
    blob(bm, uvl, c + n * (0.003 + 0.002 * layers), ax * R * 0.13, ay * R * 0.13, n * R * 0.11, mi=mi_centre, seg=8)


pc, pn = on_head(V((-0.34, -0.085, 1.80)), V((0.0, 0.0, 1.69)), 0.004)
if pc is None:
    pc, pn = V((-0.085, 0.03, 1.735)), V((-1, 0, 0.3)).normalized()
up = (V((0, 0, 1)) - pn * pn.z).normalized(); fw = pn.cross(up).normalized()
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
for ang, ln, wd in ((-20, 0.078, 0.020), (16, 0.060, 0.018), (50, 0.044, 0.015)):      # three wing lobes fanning up
    d = (up * math.cos(math.radians(ang)) + fw * math.sin(math.radians(ang))).normalized(); sd = pn.cross(d).normalized()
    c = pc + d * ln * 0.5 + pn * 0.010
    blob(bm, uvl, c, d * ln * 0.55, sd * wd, pn * 0.0030, mi=0, seg=10)
    blob(bm, uvl, c - d * ln * 0.04 + pn * 0.0045, d * ln * 0.40, sd * wd * 0.66, pn * 0.0040, mi=1, seg=10)
flower(bm, uvl, pc - up * 0.010 - fw * 0.014 + pn * 0.010, pn, 0.028, 9, 0, 2, layers=2)
flower(bm, uvl, pc - up * 0.040 - fw * 0.002 + pn * 0.007, pn, 0.018, 8, 0, 2)
hairpiece = obj_from(bm, "hairpiece", "head", M_DARK, M_ENAMEL, M_GOLD)

# earrings: a small dark flower with a pearl and a pearl drop
bm = bmesh.new(); uvl = bm.loops.layers.uv.new("UVMap")
for sx in (1, -1):
    best = None
    for dy in (0.0, 0.008, 0.016, 0.024, -0.008):       # the lobe: the outermost point low on the ear
        h = head_bvh.ray_cast(V((sx * 0.4, dy, 1.607)), V((-sx, 0, 0)))
        if h[0] is not None and (best is None or abs(h[0].x) > abs(best.x)):
            best = h[0]
    ec = (best or V((sx * 0.078, 0.005, 1.607))) + V((sx * 0.003, 0, -0.004))
    flower(bm, uvl, ec, V((sx, 0, 0)), 0.0085, 5, 0, 1)
    blob(bm, uvl, ec + V((sx * 0.002, 0, -0.012)), V((0.0035, 0, 0)), V((0, 0.0035, 0)), V((0, 0, 0.0035)), mi=1, seg=8)
    sweep(bm, uvl, [ec + V((sx * 0.002, 0, -0.002 - 0.007 * q / 3)) for q in range(4)], [0.0007] * 4, [0.0007] * 4, [V((0, -1, 0))] * 4, sides=4, mi=2)
earrings = obj_from(bm, "earrings", "head", M_DARK, M_PEARL, M_GOLD)

# ---------------------------------------------------------------- body under the gown; neck and feet cuts
def hidden(v):
    p = v.co
    if p.z > 1.50 or p.z < 0.060:
        return True
    return in_bodice(p, armw[v.index]) and 1.08 < p.z < 1.44 and ekd.find(p)[2] > 0.03


cut(body, hidden)
bind(body); body.name = "h2_body"
hk = len(head.data.shape_keys.key_blocks)
cut(head, lambda v: v.co.z < 1.47)
assert len(head.data.shape_keys.key_blocks) == hk
bind(head); head.name = "h2_head"
for s in "LR":
    bind(bpy.data.objects["eyeball_" + s])
col.hide_render = True

add_outline(head, only_slot=0, pred=lambda c: c.z > 1.52)
add_outline(body, pred=lambda c: (0.97 < c.z < 1.44) or (abs(c.x) > 0.19 and c.z > 0.5))       # the legs are inside the skirt
for o in (bodice, collar, skirt, bun, fringe, locks, bow, *bands):
    add_outline(o)

meshes = [o for o in sc.objects if o.type == "MESH" and o is not col]
tris = {o.name: sum(len(p.vertices) - 2 for p in o.data.polygons) for o in meshes}
print("H2 triangles", tris, "total", sum(tris.values()))
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "heroine2.blend"))

# ---------------------------------------------------------------- export (meshes + weights; the clips come from graft.mjs)
bpy.ops.object.select_all(action="DESELECT")
for o in meshes + [rig]:
    o.hide_set(False); o.select_set(True)
bpy.context.view_layer.objects.active = rig
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT, "h2_blender.glb"), export_format="GLB", use_selection=True,
                          export_animations=False, export_morph=True, export_skins=True, export_apply=False,
                          export_materials="EXPORT", export_image_format="AUTO")

# ---------------------------------------------------------------- views for the contact sheet
nt = M_LINE.node_tree                      # Cycles has no face culling: draw the hull's far side only
for n_ in list(nt.nodes):
    nt.nodes.remove(n_)
o_ = nt.nodes.new("ShaderNodeOutputMaterial"); mx = nt.nodes.new("ShaderNodeMixShader"); ge = nt.nodes.new("ShaderNodeNewGeometry")
lp = nt.nodes.new("ShaderNodeLightPath"); mth = nt.nodes.new("ShaderNodeMath"); mth.operation = "SUBTRACT"; mth.use_clamp = True
em = nt.nodes.new("ShaderNodeEmission"); em.inputs[0].default_value = (0.01, 0.01, 0.015, 1); tr = nt.nodes.new("ShaderNodeBsdfTransparent")
nt.links.new(lp.outputs["Is Camera Ray"], mth.inputs[0]); nt.links.new(ge.outputs["Backfacing"], mth.inputs[1])     # line = camera ray and front face
nt.links.new(mth.outputs[0], mx.inputs[0]); nt.links.new(tr.outputs[0], mx.inputs[1]); nt.links.new(em.outputs[0], mx.inputs[2]); nt.links.new(mx.outputs[0], o_.inputs[0])
sc.render.engine = "CYCLES"; sc.cycles.samples = 96; sc.cycles.transparent_max_bounces = 24
try:
    pr = bpy.context.preferences.addons["cycles"].preferences; pr.compute_device_type = "OPTIX"; pr.get_devices()
    for d in pr.devices:
        d.use = True
    sc.cycles.device = "GPU"
except Exception as e:
    print("H2 cpu render", e)
sc.view_settings.view_transform = "Standard"
w = bpy.data.worlds.new("w"); w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.72, 0.73, 0.76, 1); w.node_tree.nodes["Background"].inputs[1].default_value = 0.85
sc.world = w
piv = bpy.data.objects.new("pivot", None); sc.collection.objects.link(piv)
cam = bpy.data.objects.new("cam", bpy.data.cameras.new("cam")); sc.collection.objects.link(cam)
cam.data.type = "ORTHO"; cam.rotation_euler = (math.pi / 2, 0, 0); cam.parent = piv
sun = bpy.data.objects.new("sun", bpy.data.lights.new("sun", "SUN")); sc.collection.objects.link(sun)
sun.data.energy = 2.2; sun.data.angle = 0.4; sun.rotation_euler = (math.radians(58), 0, math.radians(-28)); sun.parent = piv
sc.camera = cam
SHOTS = [("front", 0, 1.98, 0.905, 640, 1240), ("back", 180, 1.98, 0.905, 640, 1240), ("side", 90, 1.98, 0.905, 640, 1240), ("q34", 35, 1.98, 0.905, 640, 1240),
         ("face", 0, 0.46, 1.66, 620, 620), ("face34", 40, 0.46, 1.66, 620, 620), ("hairback", 180, 0.46, 1.66, 620, 620), ("lacing", 58, 0.5, 0.86, 620, 620)]
for name, az, scale, cz, rx, ry in SHOTS:
    piv.rotation_euler = (0, 0, math.radians(az))
    cam.data.ortho_scale = scale * (1 if ry >= rx * 1.5 else 1.0); cam.location = (0, -5, cz)
    sc.render.resolution_x, sc.render.resolution_y = rx, ry
    sc.render.filepath = os.path.join(OUT, "view_" + name + ".png")
    bpy.ops.render.render(write_still=True)
print("H2 done")
