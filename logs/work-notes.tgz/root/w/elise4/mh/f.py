import json,os,numpy as np
os.chdir('/root/w/elise4/mh')
sk=json.load(open('default.mhskel')); w=json.load(open('default_weights.mhw'))['weights']
V=[]
for l in open('base.obj'):
    if l.startswith('v '): V.append([float(x) for x in l.split()[1:4]])
V=np.array(V); P=np.stack([V[:,0],-V[:,2],V[:,1]],1)*0.1; P[:,2]-=P[:13380,2].min()
J={k:P[v].mean(0) for k,v in sk['joints'].items()}
for b in ['root','pelvis.L','spine05','spine04','spine03','spine02','spine01','neck01','neck02','neck03','head','clavicle.L','shoulder01.L','upperarm01.L','upperarm02.L','lowerarm01.L','lowerarm02.L','wrist.L','metacarpal2.L','finger1-1.L','finger2-1.L','finger3-1.L','finger3-3.L','upperleg01.L','upperleg02.L','lowerleg01.L','lowerleg02.L','foot.L','toe1-1.L','toe1-2.L','eye.L','jaw','breast.L','special01','oris01','oris05','orbicularis03.L','orbicularis04.L','oculi01.L','levator02.L']:
    B=sk['bones'][b]; print(b,np.round(J[B['head']],3).tolist(),np.round(J[B['tail']],3).tolist(),B['parent'], len(w.get(b,[])))
b=P[:13380]; print('height',b[:,2].max(),'bbox',b.min(0).round(3),b.max(0).round(3))
print('chin/nose: frontmost y near x=0 by z'); 
for z in np.arange(1.40,1.70,0.02):
    m=(abs(b[:,2]-z)<0.01)&(abs(b[:,0])<0.01); print(round(z,2), b[m,1].min().round(3) if m.any() else None, end='; ')
print()
for z in [0.2,0.45,0.6,0.8,0.9,1.0,1.1,1.2,1.3]:
    m=(abs(b[:,2]-z)<0.01); print(z,'x',b[m,0].min().round(3),b[m,0].max().round(3),'y',b[m,1].min().round(3),b[m,1].max().round(3))
