import numpy as np
V=[];F=[];g=None
for l in open('/root/w/elise4/mh/base.obj'):
    p=l.split()
    if not p: continue
    if p[0]=='v': V.append([float(x) for x in p[1:4]])
    elif p[0]=='g': g=p[1]
    elif p[0]=='f' and g=='body': F.append([int(x.split('/')[0])-1 for x in p[1:]])
V=np.array(V); P=np.stack([V[:,0],-V[:,2],V[:,1]],1)*0.1; P[:,2]-=P[:13380,2].min(); F=np.array(F)
par=np.arange(13380)
def find(i):
    while par[i]!=i: par[i]=par[par[i]]; i=par[i]
    return i
for f in F:
    for k in range(4):
        a,b=find(f[k]),find(f[(k+1)%4])
        if a!=b: par[a]=b
lab=np.array([find(i) for i in range(13380)]); u,c=np.unique(lab,return_counts=True)
for uu,cc in zip(u,c): m=lab==uu; print(cc, P[:13380][m].min(0).round(3), P[:13380][m].max(0).round(3))
