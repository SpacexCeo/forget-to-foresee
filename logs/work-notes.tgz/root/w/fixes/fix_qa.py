# QA views for the town fixes: run inside art/town with Blender; argv after "--": out_dir tag
import os, sys
sys.path.insert(0, os.getcwd())
import bpy
from mathutils import Vector
import build_town as B
ftf, bl = B.ftf, B.bl
out, tag = sys.argv[sys.argv.index("--") + 1:][:2]
sc = ftf.reset_scene(); ftf.use_gpu(sc, "town"); col = ftf.new_collection("QA")
for piece in ("town_terrain", "town_block_gate"):
    pv = B.PIVOT[piece]
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=os.path.join(B.OUT_DIR, piece + ".glb"))
    for o in set(bpy.data.objects) - before:
        if o.parent is None: o.location = Vector(o.location) + Vector(bl(pv))
        if o.name.endswith("_col") or "_col." in o.name: o.hide_render = True
sc.world = ftf.sky_world("TownSky", zenith=(0.16, 0.34, 0.62), horizon=(0.80, 0.84, 0.86), ground=(0.50, 0.52, 0.52), strength=1.6)
ftf.add_sun(col, energy=5.0, color=(1.0, 0.90, 0.72), elev=46, azim=-140, angle=2)
views = {"gate": ((0.9, 2.2, 24.0), (0, 4.7, 33), 20), "emblem": ((1.6, 5.2, 27.5), (0, 7.8, 32.8), 50),
         "leaf": ((-1.2, 1.9, 30.2), (2.6, 2.3, 34.2), 20), "cart": ((-16.2, 2.2, 17.4), (-18.5, 0.95, 15.2), 35)}
for name, (loc, tgt, lens) in views.items():
    ftf.setup_cycles(sc, 960, 600, 64)
    sc.view_settings.exposure = -0.3
    cam = ftf.add_camera("cam_" + name, bl(loc), bl(tgt), lens=lens, col=col, clip_end=3000)
    ftf.render_to(sc, cam, os.path.join(out, f"{tag}_{name}.jpg"))
