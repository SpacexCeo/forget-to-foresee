import sys,glob,os
from PIL import Image, ImageDraw
d=sys.argv[1]; out=sys.argv[2]; names=sys.argv[3:] or sorted(os.path.basename(f)[:-4] for f in glob.glob(d+'/*.png'))
cols=min(6,len(names)); rows=(len(names)+cols-1)//cols; T=256
s=Image.new('RGBA',(cols*T,rows*(T+18)),(38,42,48,255)); dr=ImageDraw.Draw(s)
for i,n in enumerate(names):
  im=Image.open(f'{d}/{n}.png').convert('RGBA').resize((T,T),Image.LANCZOS); x,y=(i%cols)*T,(i//cols)*(T+18)
  s.alpha_composite(im,(x,y)); dr.text((x+6,y+T+3),n,fill=(220,215,200,255))
s.convert('RGB').save(out,quality=88)
