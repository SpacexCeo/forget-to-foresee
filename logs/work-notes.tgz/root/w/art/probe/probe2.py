import bpy, collections
o = [x for x in bpy.data.objects if x.type == "MESH" and x.name.startswith("townsfolk")][0]
me = o.data; mw = o.matrix_world
def val(name, i):
    a = me.attributes[name]
    d = a.data[i] if a.domain == "POINT" else None
    if d is None: return None
    return tuple(round(x, 2) for x in (d.color if hasattr(d, "color") else (d.value,)))[:3]
for name in ("gcol", "tcol", "trim"):
    print("ATTR", name, me.attributes[name].domain, me.attributes[name].data_type)
grp = collections.Counter()
for v in me.vertices:
    p = mw @ v.co
    if p.x > 0.02 and 0.245 < p.z < 0.265:
        grp[(val("gcol", v.index), val("tcol", v.index), val("trim", v.index))] += 1
print("DISC", grp.most_common(5))
grp = collections.Counter()
for v in me.vertices:
    p = mw @ v.co
    if p.x > 0.02 and 0.36 < p.z < 0.42:
        grp[(val("gcol", v.index), val("tcol", v.index))] += 1
print("TROUSERS", grp.most_common(3))
grp = collections.Counter()
for v in me.vertices:
    p = mw @ v.co
    if p.x > 0.02 and 0.10 < p.z < 0.2:
        grp[(val("gcol", v.index), val("tcol", v.index))] += 1
print("BOOT", grp.most_common(3))
