import bpy, sys, collections
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=sys.argv[sys.argv.index("--") + 1])
hits = collections.Counter(); ex = {}
for o in bpy.data.objects:
    if o.type != "MESH": continue
    me = o.data; mw = o.matrix_world
    for p in me.polygons:
        c = mw @ p.center
        gx, gy, gz = c.x, c.z, -c.y          # game space
        if 2.4 < abs(gx) < 9 and 36.0 < gz < 44 and gy > 1.5:
            n = (mw.to_3x3() @ p.normal).normalized()
            key = (o.name, me.materials[p.material_index].name if me.materials else None, round(n.x, 1), round(n.z, 1), round(-n.y, 1))
            hits[key] += 1
            ex.setdefault(key, (round(gx, 2), round(gy, 2), round(gz, 2), round(p.area, 2)))
for k, v in hits.most_common(20):
    print("HIT", v, k, ex[k])
