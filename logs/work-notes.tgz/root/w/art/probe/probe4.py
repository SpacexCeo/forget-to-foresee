import bpy, sys
from mathutils import Vector
sys.path.insert(0, "/root/w/art/town2/art/town"); sys.path.insert(0, "/root/w/art/town2/art/common")
import town_plan as P
bpy.ops.wm.read_factory_settings(use_empty=True)
d = "/root/w/art/town2/art/town/out/"
for f in ("town_terrain", "town_block_gate", "town_block_mid", "town_block_square", "town_temple"):
    bpy.ops.import_scene.gltf(filepath=d + f + ".glb")
for o in bpy.data.objects:
    if o.name.endswith("_col"): bpy.data.objects.remove(o)
dg = bpy.context.evaluated_depsgraph_get(); sc = bpy.context.scene
miss = []
for h in P.HOUSES:
    x0, x1, z0, z1 = P.house_rect(h)
    cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
    # Blender: (x, -z, y); cast down from 40 m
    hit, loc, n, i, ob, m = sc.ray_cast(dg, Vector((cx, -cz, 40.0)), Vector((0, 0, -1)))
    print("HOUSE", h[0] if isinstance(h, (tuple, list)) else h.get("id"), round(cx, 1), round(cz, 1), hit and ob.name, hit and round(loc.z, 2))
# ground grid holes: cast down on a 2 m grid inside the walls and report misses
for gx in range(-44, 45, 2):
    for gz in range(-54, 34, 2):
        hit, loc, n, i, ob, m = sc.ray_cast(dg, Vector((gx + 0.5, -(gz + 0.5), 40.0)), Vector((0, 0, -1)))
        if not hit:
            miss.append((gx, gz))
print("MISS", len(miss), miss[:80])
