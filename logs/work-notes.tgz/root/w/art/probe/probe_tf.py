import bpy, math, collections
for o in bpy.data.objects:
    if o.type != "MESH": continue
    me = o.data
    attrs = [a.name for a in me.attributes]
    print("OBJ", o.name, len(me.vertices), attrs[:12], [m.name for m in me.materials][:4])
    mw = o.matrix_world
    zs = sorted(set(round((mw @ v.co).z, 2) for v in me.vertices if 0.25 < (mw @ v.co).z < 0.45))
    # per 1 cm band on the right leg (x>0): max horizontal distance from the leg's centre
    band = collections.defaultdict(list)
    for v in me.vertices:
        p = mw @ v.co
        if p.x > 0.02 and 0.2 < p.z < 0.5:
            band[round(p.z, 2)].append(p)
    for z in sorted(band):
        ps = band[z]; cx = sum(p.x for p in ps)/len(ps); cy = sum(p.y for p in ps)/len(ps)
        r = sorted(math.hypot(p.x-cx, p.y-cy) for p in ps)
        print("z %.2f n %3d r_med %.3f r_max %.3f" % (z, len(ps), r[len(r)//2], r[-1]))
