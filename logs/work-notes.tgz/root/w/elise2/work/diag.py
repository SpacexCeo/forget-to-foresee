import numpy as np, json
from PIL import Image
d=np.load('body_dec.npz'); V,F,part=d['V'],d['F'],d['part']
print('V',V.shape,'F',F.shape,'part counts',np.bincount(part), 'bbox',V.min(0).round(3),V.max(0).round(3))
for p in (2,3):
    m=part==p; print('leg',p,'z',V[m,2].min().round(3),V[m,2].max().round(3),'x',V[m,0].min().round(3),V[m,0].max().round(3),'n',m.sum(), 'faces', (part[F].max(1)==p).sum())
fp=part[F].max(1); F0=F[fp<2]
e=np.sort(np.concatenate([F0[:,[0,1]],F0[:,[1,2]],F0[:,[2,0]]]),1); u,c=np.unique(e,axis=0,return_counts=True); b=u[c==1]; print('boundary edges',len(b),'nonmanifold',(c>2).sum())
# loops
import collections
adj=collections.defaultdict(list)
for a_,b_ in b: adj[a_].append(b_); adj[b_].append(a_)
seen=set(); loops=[]
for s in adj:
    if s in seen: continue
    st=[s]; comp=[]
    while st:
        v=st.pop()
        if v in seen: continue
        seen.add(v); comp.append(v); st+=adj[v]
    loops.append(np.array(comp))
loops.sort(key=len,reverse=True)
for L in loops[:14]:
    P=V[L]; print('loop n',len(L),'z',P[:,2].min().round(3),P[:,2].max().round(3),'x',P[:,0].min().round(3),P[:,0].max().round(3),'y',P[:,1].min().round(3),P[:,1].max().round(3))
print('n loops',len(loops))
L=loops[0]; P=V[L]; ang=np.degrees(np.arctan2(P[:,0],-P[:,1]))  # 0 = front, +90 = her left (+x)
low=P[:,2]<0.3
h,_=np.histogram(ang[low],bins=36,range=(-180,180)); print('hem boundary verts per 10deg',h.tolist())
for a0 in range(-180,180,20):
    m=low&(ang>=a0)&(ang<a0+20)
    if m.any(): print(a0,'z min/med/max',P[m,2].min().round(3),np.median(P[m,2]).round(3),P[m,2].max().round(3),'r',np.hypot(P[m,0],P[m,1]).mean().round(3))
hi=~low; print('high boundary pts (slit?)'); 
for z0 in np.arange(0.3,1.5,0.1):
    m=(P[:,2]>=z0)&(P[:,2]<z0+0.1)
    if m.any(): print(round(z0,1),'n',m.sum(),'x',P[m,0].min().round(3),P[m,0].max().round(3),'y',P[m,1].min().round(3),P[m,1].max().round(3),'ang',ang[m].min().round(0),ang[m].max().round(0))
# skirt cross-section radius by angle at several z
sk=(part<2)
for z0 in (0.05,0.1,0.15,0.2,0.3,0.5,0.7,0.85):
    m=sk&(abs(V[:,2]-z0)<0.012); a=np.degrees(np.arctan2(V[m,0],-V[m,1])); r=np.hypot(V[m,0],V[m,1])
    row=[]
    for a0 in range(-180,180,30):
        mm=(a>=a0)&(a<a0+30); row.append('%.2f/%d'%(r[mm].mean() if mm.any() else 0, mm.sum()))
    print('z',z0,' '.join(row))
# texture colours
b=np.load('bake_in.npz'); P3,UV,pp=b['P'],b['UV'],b['part']; im=np.asarray(Image.open('elise_base.png').convert('RGB')).astype(float)/255; R=im.shape[0]
c=P3.mean(1); uv=UV.mean(1); col=im[np.clip(((1-uv[:,1])*R).astype(int),0,R-1),np.clip((uv[:,0]*R).astype(int),0,R-1)]
print('parts in bake',np.bincount(pp))
fm=(pp==1)&(c[:,1]<-0.03)&(c[:,2]>1.55)&(c[:,2]<1.64)&(abs(c[:,0])<0.075)
iris=fm&(col[:,0]>0.3)&(col[:,0]>1.6*col[:,1])&(col[:,0]<0.8)
for sg in (1,-1):
    m=iris&(c[:,0]*sg>0); print('iris',sg,m.sum(),c[m].mean(0).round(4),c[m].min(0).round(4),c[m].max(0).round(4))
dark=fm&(col.max(1)<0.35)
for sg in (1,-1):
    m=dark&(c[:,0]*sg>0.012); print('dark eye',sg,m.sum(),c[m].min(0).round(4),c[m].max(0).round(4))
# mouth: dark-ish/red line near x=0 between z 1.50..1.56
mm=(pp==1)&(c[:,1]<-0.05)&(c[:,2]>1.49)&(c[:,2]<1.575)&(abs(c[:,0])<0.03)
sk_=np.median(col[mm],0); print('face skin',sk_.round(3))
dif=np.abs(col-sk_).sum(1)
for z0 in np.arange(1.49,1.575,0.005):
    m=mm&(c[:,2]>=z0)&(c[:,2]<z0+0.005)
    if m.any(): print('z %.3f n %d meandif %.3f maxdif %.3f xspan %.3f %.3f y %.3f'%(z0,m.sum(),dif[m].mean(),dif[m].max(),c[m&(dif>0.25),0].min() if (m&(dif>0.25)).any() else 0,c[m&(dif>0.25),0].max() if (m&(dif>0.25)).any() else 0,c[m,1].min()))
# lacing zone skin/dress map: front-left, z .6..1.0
zm=(pp==0)&(c[:,2]>0.55)&(c[:,2]<1.0)&(c[:,0]>0.0)&(c[:,1]<0.05)
a=np.degrees(np.arctan2(c[:,0],-c[:,1])); bright=col[:,0]>0.6
print('lacing zone: rows z, cols angle 0..120 step 8: fraction bright (skin) /count')
for z0 in np.arange(0.96,0.54,-0.03):
    row=[]
    for a0 in range(0,120,8):
        m=zm&(c[:,2]<z0)&(c[:,2]>=z0-0.03)&(a>=a0)&(a<a0+8); row.append('%2d' % (99*bright[m].mean()) if m.sum()>0 else ' .')
    print('%.2f'%z0,' '.join(row))
lg=(pp==4)
print('left leg tex: z rows -> median colour, frac dark')
for z0 in np.arange(0.9,0.1,-0.04):
    m=lg&(c[:,2]<z0)&(c[:,2]>=z0-0.04)
    if m.any(): print('%.2f'%z0,np.median(col[m],0).round(2),m.sum(), 'r', np.hypot(c[m,0]-c[m,0].mean(),c[m,1]-c[m,1].mean()).mean().round(3), 'ctr',c[m,0].mean().round(3),c[m,1].mean().round(3))
