"""Elise: does the visible (left) leg ever come through the gown? Skins the exported model with every clip of the
side-car file (plain linear blend skinning, as the engine does) and measures, per frame, how far each leg vertex
stands outside the nearest gown triangle (open slit and hem edges excluded). Exits 1 if any clip exceeds the limit.
    python3 skirt_check.py <model_raw.glb> <clips.glb> <model>_check.npz [limit m, default 0.004]"""
import json, struct, sys
import numpy as np, trimesh
from scipy.spatial import cKDTree
def glb(p):
    d = open(p, 'rb').read(); jl = struct.unpack_from('<I', d, 12)[0]; return json.loads(d[20:20 + jl]), d[28 + jl:]
def acc(J, B, i):
    a = J['accessors'][i]; v = J['bufferViews'][a['bufferView']]; n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]
    dt = {5120: 'i1', 5121: 'u1', 5122: 'i2', 5123: 'u2', 5125: 'u4', 5126: 'f4'}[a['componentType']]; o = v.get('byteOffset', 0) + a.get('byteOffset', 0); st = v.get('byteStride', 0)
    if st and st != np.dtype(dt).itemsize * n: return np.stack([np.frombuffer(B, dt, n, o + k * st) for k in range(a['count'])])
    return np.frombuffer(B, dt, a['count'] * n, o).reshape(a['count'], n)
def qm(q):
    x, y, z, w = q; return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
J, B = glb(sys.argv[1]); C, CB = glb(sys.argv[2]); K = np.load(sys.argv[3]); LIM = float(sys.argv[4]) if len(sys.argv) > 4 else 0.004
node = next(n for n in J['nodes'] if 'mesh' in n); pr = J['meshes'][node['mesh']]['primitives'][0]; sk = J['skins'][node['skin']]
P = acc(J, B, pr['attributes']['POSITION']).astype(float); JN = acc(J, B, pr['attributes']['JOINTS_0']).astype(int); JW = acc(J, B, pr['attributes']['WEIGHTS_0']).astype(float); JW /= JW.sum(1, keepdims=True)
IB = acc(J, B, sk['inverseBindMatrices']).reshape(-1, 4, 4).transpose(0, 2, 1).astype(float); joints = sk['joints']; par = {c: i for i, n in enumerate(J['nodes']) for c in n.get('children', [])}
b2g = lambda p: np.stack([p[..., 0], p[..., 2], -p[..., 1]], -1); T = cKDTree(P)
dl, il = T.query(b2g(K['leg'])); dg, ig = T.query(b2g(K['gown']).reshape(-1, 3)); ig = ig.reshape(-1, 3); assert dl.max() < 1e-4 and dg.max() < 1e-4, (dl.max(), dg.max())
use = np.unique(np.r_[il, ig.ravel()]); rem = np.full(len(P), -1); rem[use] = np.arange(len(use)); il = rem[il]; ig = rem[ig]
e = np.sort(np.concatenate([ig[:, [0, 1]], ig[:, [1, 2]], ig[:, [2, 0]]]), 1); u, inv, cnt = np.unique(e, axis=0, return_inverse=True, return_counts=True); edge = (cnt[inv.ravel()] == 1).reshape(3, -1).any(0)
name2 = {n.get('name'): i for i, n in enumerate(J['nodes'])}; cname = {i: n.get('name') for i, n in enumerate(C['nodes'])}
def world(loc):
    W = {}
    def w(i):
        if i not in W:
            n = J['nodes'][i]; t, r, s = loc.get(i, (n.get('translation', [0, 0, 0]), n.get('rotation', [0, 0, 0, 1]), n.get('scale', [1, 1, 1])))
            M = np.eye(4); M[:3, :3] = qm(r) * np.asarray(s); M[:3, 3] = t; W[i] = (w(par[i]) @ M) if i in par else M
        return W[i]
    return np.stack([w(j) for j in joints])
import ezones as Z
jn={J['nodes'][j]['name']:k for k,j in enumerate(joints)}; gu=np.unique(ig); R_=P[use][gu]; bx,by,bz=R_[:,0],-R_[:,2],R_[:,1]
def wfun(xs,att):
    W=Z.skirt_weights(bx,by,bz); sL=np.clip((bx-xs)/0.03+0.5,0,1); tot=W['thigh_L']+W['thigh_R']; out={}
    for k,v in W.items():
        if k=='pelvis': continue
        base=k.replace('_R','_L').replace('FR_','FL_').replace('BR_','BL_'); pair=W[base]+W[base.replace('_L','_R').replace('FL_','FR_').replace('BL_','BR_')] if False else None
    wth=1-W['pelvis']; legsum={}
    for nm in ('thigh','shin'):
        t=W[nm+'_L']+W[nm+'_R']; out[nm+'_L']=t*sL; out[nm+'_R']=t*(1-sL)*(1-att)
    for nm in ('skirt_F','skirt_B'):
        t=W[nm+'L_0']+W[nm+'R_0']; out[nm+'L_0']=t*sL; out[nm+'R_0']=t*(1-sL)*(1-att)
    out['pelvis']=1-sum(out.values()); return out
def w2(xs,att,up,dn,hip=0.25):
    wth=Z.sstep((0.93-bz)/hip); sL=np.clip((bx-xs)/0.03+0.5,0,1); fr=np.clip((-(by-0.01)+0.03)/0.06,0,1)
    tk=fr*Z.sstep((bz-(Z.KZ-dn))/dn)+(1-fr)*Z.sstep((bz-Z.KZ)/up); hem=np.clip((0.28-bz)/0.28,0,1)*0.6; o={}
    for sd,sv in (('L',sL),('R',(1-sL)*(1-att))):
        o['thigh_'+sd]=wth*sv*tk; o['shin_'+sd]=wth*sv*(1-tk)*(1-hem); o['skirt_F%s_0'%sd]=wth*sv*(1-tk)*hem*fr; o['skirt_B%s_0'%sd]=wth*sv*(1-tk)*hem*(1-fr)
    o['pelvis']=1-sum(o.values()); return o
VAR={'F all L':wfun(-9,0),'G fb 0.25':w2(-0.03,0,0.25,0.25),'H fb 0.15':w2(-0.03,0,0.15,0.15),'I fb .25 allL':w2(-9,0,0.25,0.25),'J fb .35/.25':w2(-0.03,0,0.35,0.25),'K fb .25 split -.075 Rhalf':w2(-0.075,0.5,0.25,0.25)}
RES={k:[] for k in VAR}
bad = 0
for A in C['animations']:
    tr = {}; nk = 0
    for ch in A['channels']:
        s = A['samplers'][ch['sampler']]; i = name2.get(cname[ch['target']['node']])
        if i is not None and ch['target']['path'] in ('rotation', 'translation'): v = acc(C, CB, s['output']).astype(float); tr[(i, ch['target']['path'])] = v; nk = max(nk, len(v))
    worst = 0.0; nb = 0; fr = range(0, nk, 2); wv = None
    for f in fr:
        loc = {}
        for (i, path), v in tr.items():
            n = J['nodes'][i]; cur = loc.get(i, (n.get('translation', [0, 0, 0]), n.get('rotation', [0, 0, 0, 1]), n.get('scale', [1, 1, 1]))); val = v[min(f, len(v) - 1)]
            loc[i] = (val, cur[1], cur[2]) if path == 'translation' else (cur[0], val, cur[2])
        S = world(loc) @ IB; Mv = (S[JN[use]] * JW[use][:, :, None, None]).sum(1); D = (Mv[:, :3, :3] @ P[use][:, :, None])[:, :, 0] + Mv[:, :3, 3]
        if A['name'] not in ('walk','run','greet'): continue
        for vn,Wv in VAR.items():
            M2=sum(Wv[b][:,None,None]*S[jn[b]][None] for b in Wv); D2=D.copy(); D2[gu]=(M2[:,:3,:3]@R_[:,:,None])[:,:,0]+M2[:,:3,3]
            gm = trimesh.Trimesh(D2, ig, process=False); cp, dist, tid = trimesh.proximity.closest_point(gm, D2[il]); out = ((D2[il] - cp) * gm.face_normals[tid]).sum(1)
            out = np.where(edge[tid] | (dist > 0.05) | (abs(P[use][ig[tid]][:,:,1].mean(1) - P[use][il][:,1]) > 0.12), 0, out); RES[vn].append((A['name'],float(out.max()),int((out>0.004).sum())))
        out=np.zeros(1); nb += out.max() > LIM
        if out.max() > worst: worst = float(out.max()); wv = P[use][il[out.argmax()]]
    print('%-10s frames %3d  worst leg-outside-gown %.4f m  frames over %.3f: %d' % (A['name'], len(fr), worst, LIM, nb), '' if wv is None else ' worst vertex at rest: height %.2f, side %.2f, front %.2f' % (wv[1], wv[0], wv[2])); bad += nb > 0


for vn,r in RES.items():
    print(vn, {c:'frames over %d/%d, worst %.3f, mean verts out %.0f'%(sum(x[1]>0.004 for x in r if x[0]==c),sum(x[0]==c for x in r),max(x[1] for x in r if x[0]==c),np.mean([x[2] for x in r if x[0]==c])) for c in ('walk','run','greet')})
