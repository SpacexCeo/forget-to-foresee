import bpy, bmesh, math, sys
import numpy as np
el = bpy.data.objects['elise']; me = el.data; sc = bpy.context.scene
el.data.shape_keys and [el.shape_key_remove(k) for k in reversed(el.data.shape_keys.key_blocks)]
sc.render.engine = 'BLENDER_WORKBENCH'; sh = sc.display.shading; sh.light = 'FLAT'; sh.color_type = 'TEXTURE'; sh.show_backface_culling = True; sc.view_settings.view_transform = 'Standard'
w = bpy.data.worlds.new('w'); sc.world = w; w.color = (0.75, 0.3, 0.78)
cam = bpy.data.objects.new('c', bpy.data.cameras.new('c')); sc.collection.objects.link(cam); cam.data.type = 'ORTHO'; sc.camera = cam
az = math.radians(40); cam.location = (0.12 + 10 * math.sin(az), -0.05 - 10 * math.cos(az), 0.66); cam.rotation_euler = (math.pi / 2, 0, az); cam.data.ortho_scale = 0.26; sc.render.resolution_x = sc.render.resolution_y = 400
def variant(name, keep):
    bm = bmesh.new(); bm.from_mesh(me); L = bm.faces.layers.int['part']
    bmesh.ops.delete(bm, geom=[f for f in bm.faces if not keep(f, f[L])], context='FACES'); m2 = bpy.data.meshes.new(name); bm.to_mesh(m2); bm.free()
    for mt in me.materials: m2.materials.append(mt)
    o = bpy.data.objects.new(name, m2); sc.collection.objects.link(o); el.hide_render = True; sc.render.filepath = f'r/dbg_{name}.png'; bpy.ops.render.render(write_still=True); o.hide_render = True
variant('a_nohull', lambda f, p: f.material_index == 0)
variant('b_nogown', lambda f, p: p != 6)
variant('c_leg_only', lambda f, p: p in (4, 5) and f.material_index == 0)
variant('d_leg_hull', lambda f, p: p in (4, 5))
variant('e_shell_gown_base', lambda f, p: p in (0, 6) and f.material_index == 0)
