import bpy, numpy as np
for mass, air, ts in ((0.03, 0.0, 1), (0.03, 0.0, 0.5), (0.3, 0.0, 0.5), (1.0, 0.0, 0.5), (1.0, 0.0, 1.0), (0.3, 0.3, 0.5), (0.03,0.03,0.5)):
    bpy.ops.wm.read_factory_settings(use_empty=True); sc = bpy.context.scene; sc.render.fps = 60
    bpy.ops.mesh.primitive_grid_add(x_subdivisions=6, y_subdivisions=6, size=0.2); o = bpy.context.object
    md = o.modifiers.new('c', 'CLOTH'); md.settings.mass = mass; md.settings.air_damping = air; md.settings.time_scale = ts; md.point_cache.frame_end = 100
    z = []
    for f in range(1, 32):
        sc.frame_set(f); z.append(-o.evaluated_get(bpy.context.evaluated_depsgraph_get()).data.vertices[0].co.z)
    print('CAL mass %.2f air %.2f ts %.2f: fall after 10/20/30 frames %.4f %.4f %.4f (free fall at 60 fps: 0.136 0.545 1.226)' % (mass, air, ts, z[10], z[20], z[30]))
