# viz.py <repo> <clips.glb or 'bake'> <clip> <out.jpg>: side and front wireframes of the skinned gown and the leg capsules over a clip
import sys, os, json, struct, numpy as np
R = sys.argv[1]; sys.path.insert(0, R + '/art/anim')
from ftfanim.rig import Rig; from ftfanim import skirt
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
rig = Rig(R + '/game/public/assets/models/agent_elise.glb'); cr = skirt.ClothRig(R + '/art/agents/elise/cloth_rig.npz', rig)
d = np.load(sys.argv[2]); name = sys.argv[3]; local = d[name + '/local']; pel = d[name + '/pelvis']
F = len(local); fr = np.linspace(0, F - 1, 7).astype(int)[:6]; wr, wp = rig.fk(local[fr], pel[fr]); P = cr.skin(wr, wp); caps = cr.capsules(wr, wp)
fig, axs = plt.subplots(2, 6, figsize=(18, 9))
for k in range(6):
    for row, (ax0, ax1, sg) in enumerate(((2, 1, -1), (0, 1, 1))):
        ax = axs[row, k]; g = P[k]
        for r in range(0, g.shape[0], 2): ax.plot(sg * g[r, :, ax0], g[r, :, ax1], 'k-', lw=0.4)
        for c in range(0, g.shape[1], 5): ax.plot(sg * g[:, c, ax0], g[:, c, ax1], 'b-', lw=0.6)
        for nm, a, b, r0, r1 in caps:
            ax.plot([sg * a[k, ax0], sg * b[k, ax0]], [a[k, ax1], b[k, ax1]], '-', color='r' if nm.endswith('L') else 'g', lw=2)
            for p_, r_ in ((a[k], r0), (b[k], r1)): ax.add_patch(plt.Circle((sg * p_[ax0], p_[ax1]), r_, fill=False, color='r' if nm.endswith('L') else 'g', lw=0.6))
        ax.set_aspect('equal'); ax.set_xlim(-0.6, 0.6); ax.set_ylim(-0.02, 1.0); ax.set_title('%s f%d %s' % (name, fr[k], 'side (front left)' if row == 0 else 'front')); ax.axis('off')
plt.tight_layout(); plt.savefig(sys.argv[4], dpi=60)
