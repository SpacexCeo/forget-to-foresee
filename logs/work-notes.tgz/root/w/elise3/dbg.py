import sys, numpy as np
sys.path.insert(0, 'art/anim')
from ftfanim.rig import Rig
rig = Rig('game/public/assets/models/agent_elise.glb'); d = np.load('../dump.npz')
for c in ('walk', 'stairs_up'):
    wr, wp = rig.fk(d[c + '/local'], d[c + '/pelvis']); i = lambda n: rig.index[n]
    for s in 'LR':
        print(c, s, 'hip y %.2f' % wp[0, i('thigh_' + s), 1], 'knee y', wp[::8, i('shin_' + s), 1].round(2).tolist(), 'knee z', wp[::8, i('shin_' + s), 2].round(2).tolist(), 'ankle y', wp[::8, i('foot_' + s), 1].round(2).tolist(), 'ankle z', wp[::8, i('foot_' + s), 2].round(2).tolist())
