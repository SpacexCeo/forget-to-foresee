"""Elise: bakes a Blender cloth simulation onto the gown's bone grid, the wrist-ribbon chains and the two face strands.
For every clip of the body motion (build_clips.py --body-out) the gown, two ribbon strips and two hair strips are
simulated as cloth: pinned to the pelvis / forearms / head, gravity, light damping, capsule colliders carried by the
bones (thigh, shin, foot and heel of both legs for the gown; torso, head, arms and the gown's volume for the ribbons
and strands). Loops run several cycles and keep the last one, closed; one-shots settle first. The bones are then
fitted to the cloth and the gown is cleared of the leg capsules under linear skinning (ftfanim/skirt.py).
    blender -b -P cloth_bake.py -- <repo> <model.glb> <cloth_rig.npz> <body.npz> <out.npz> [--only a,b] [--preview dir]"""
import bpy, bmesh, sys, os, math, time
import numpy as np
from mathutils import Quaternion
a = sys.argv[sys.argv.index("--") + 1:]; REPO, MODEL, RIGF, BODYF, OUT = a[:5]
ONLY = a[a.index('--only') + 1].split(',') if '--only' in a else None; PREV = a[a.index('--preview') + 1] if '--preview' in a else None
sys.path.insert(0, os.path.join(REPO, 'art/anim'))
from ftfanim.rig import Rig
from ftfanim import skirt as SK
from ftfanim.quat import qmul, qinv, qnorm, qrot, axis_angle
STEP = 0.03173; FPS = 1.0 / STEP     # Blender's cloth advances a fixed 0.03173 s per frame whatever the scene's frame rate (measured by free fall;
# its speed multiplier breaks the collisions with moving colliders), so the body motion is sampled at that rate
rig = Rig(MODEL); CR = SK.ClothRig(RIGF, rig); body = np.load(BODYF)
g2b = lambda p: np.stack([p[..., 0], -p[..., 2], p[..., 1]], -1); b2g = lambda p: np.stack([p[..., 0], p[..., 2], -p[..., 1]], -1)
bpy.ops.wm.read_factory_settings(use_empty=True); sc = bpy.context.scene; sc.render.fps = 32; sc.gravity = (0, 0, -9.81)
def coll(name):
    c = bpy.data.collections.new(name); sc.collection.children.link(c); return c
C_SIM, C_LEGS, C_BODY = coll('sim'), coll('col_legs'), coll('col_body')
def mesh_obj(name, V, F, col):
    me = bpy.data.meshes.new(name); me.from_pydata([tuple(map(float, v)) for v in V], [], [tuple(map(int, f)) for f in F]); me.update()
    o = bpy.data.objects.new(name, me); col.objects.link(o); return o
def capsule(p0, p1, r0, r1, seg=14, cap=4):
    """Tapered capsule mesh from p0 to p1 (Blender axes)."""
    ax = p1 - p0; L = np.linalg.norm(ax); ax = ax / L; u = np.cross(ax, [1, 0, 0]); u = u if np.linalg.norm(u) > 0.3 else np.cross(ax, [0, 1, 0]); u /= np.linalg.norm(u); v = np.cross(ax, u)
    rings = [(-r0 * math.cos(math.pi / 2 * k / cap), r0 * math.sin(math.pi / 2 * k / cap)) for k in range(1, cap + 1)]
    nb = max(2, int(L / 0.035)); rings += [(L * k / nb, r0 + (r1 - r0) * k / nb) for k in range(1, nb + 1)] + [(L + r1 * math.sin(math.pi / 2 * k / cap), r1 * math.cos(math.pi / 2 * k / cap)) for k in range(1, cap)]
    V = [p0 - ax * r0]; F = []
    for h, r in rings: V += [p0 + ax * h + (u * math.cos(2 * math.pi * i / seg) + v * math.sin(2 * math.pi * i / seg)) * r for i in range(seg)]
    V.append(p1 + ax * r1); n = len(rings)
    F += [(0, 1 + (i + 1) % seg, 1 + i) for i in range(seg)]
    for k in range(n - 1): F += [(1 + k * seg + i, 1 + k * seg + (i + 1) % seg, 1 + (k + 1) * seg + (i + 1) % seg, 1 + (k + 1) * seg + i) for i in range(seg)]
    F += [(1 + (n - 1) * seg + i, 1 + (n - 1) * seg + (i + 1) % seg, len(V) - 1) for i in range(seg)]
    return np.array(V), F
# ---- drivers: one empty per bone that carries something; its matrix is the bone's skinning transform (identity at rest)
EMP = {}
def empty(bone):
    if bone not in EMP:
        e = bpy.data.objects.new('drv_' + bone, None); C_SIM.objects.link(e); e.rotation_mode = 'QUATERNION'; EMP[bone] = e
    return EMP[bone]
for b, p0, p1, r0, r1, cset, name in CR.caps:
    V, F = capsule(g2b(p0), g2b(p1), r0, r1); o = mesh_obj('cap_%s_%d' % (name, cset), V, F, C_BODY if cset else C_LEGS); o.parent = empty(name)
    o.modifiers.new('col', 'COLLISION'); o.collision.thickness_outer = 0.008; o.collision.thickness_inner = float(os.environ.get('TIN', 0.02)); o.collision.cloth_friction = 0.5; o.collision.damping = 1.0
# a web between the two legs (thigh axis to thigh axis, shin axis to shin axis): the gown can be pushed by either leg
# but never falls between them, where two crossing colliders would wedge it
ax = {name: (p0, p1) for b, p0, p1, r0, r1, cset, name in CR.caps if cset == 0 and name[:-2] in ('thigh', 'shin')}
wv = [ax['thigh_L'][0], ax['thigh_L'][1], ax['shin_L'][1], ax['thigh_R'][0], ax['thigh_R'][1], ax['shin_R'][1]]
web = mesh_obj('web', g2b(np.array(wv)), [(0, 1, 4, 3), (1, 2, 5, 4)], C_LEGS if os.environ.get('WEB') else C_SIM)
for i, bn in enumerate(('thigh_L', 'shin_L', 'shin_L', 'thigh_R', 'shin_R', 'shin_R')):
    hk = web.modifiers.new('h%d' % i, 'HOOK'); hk.object = empty(bn); hk.falloff_type = 'NONE'; hk.vertex_indices_set([i])
web.modifiers.new('col', 'COLLISION'); web.collision.thickness_outer = 0.035; web.collision.thickness_inner = 0.035; web.collision.cloth_friction = 1.0; web.collision.damping = 0.3
# ---- cloth pieces
R_, C_ = CR.grid.shape[:2]; gi = np.arange(R_ * C_).reshape(R_, C_)
gown = mesh_obj('gown', g2b(CR.grid.reshape(-1, 3)), [(gi[j, i], gi[j + 1, i], gi[j + 1, i + 1], gi[j, i + 1]) for j in range(R_ - 1) for i in range(C_ - 1)], C_SIM)
PIECES = [dict(ob=gown, bone='pelvis', pin={int(i): 1.0 for i in gi[0]}, col=C_LEGS, mass=0.3, tens=40.0, bend=2.0, air=0.4, dist=0.012, goal=0.0)]
STRIPS = []          # (object, chain bone indices, row of every chain node)
def strip(name, chain, parent_bone, width, col, **kw):
    """A three-vertex-wide strip along a bone chain's rest line, hooked to the parent bone, pinned at the top."""
    pts = [rig.rest_wp[rig.index[b]] for b in chain] + [CR.tails[chain[-1]]]; seg = 5; rows = []; node_rows = [0]
    for k in range(len(chain)):
        for s_ in range(seg): rows.append(pts[k] + (pts[k + 1] - pts[k]) * s_ / seg)
        node_rows.append((k + 1) * seg)
    rows.append(pts[-1]); rows = np.array(rows); d = pts[-1] - pts[0]; side = np.cross(d, [0, 0, 1.0]); side /= np.linalg.norm(side)
    V = np.concatenate([rows - side * width / 2, rows, rows + side * width / 2]); n = len(rows)
    F = [(c * n + j, c * n + j + 1, (c + 1) * n + j + 1, (c + 1) * n + j) for c in range(2) for j in range(n - 1)]
    o = mesh_obj(name, g2b(V), F, C_SIM); pin = {}
    for c in range(3):
        for j in range(n): pin[c * n + j] = kw['pinw'](j / (n - 1))
    PIECES.append(dict(ob=o, bone=parent_bone, pin=pin, col=col, **{k: v for k, v in kw.items() if k != 'pinw'}))
    STRIPS.append((o, [rig.index[b] for b in chain], [n + r for r in node_rows]))
for sd in 'LR':
    strip('ribbon_' + sd, [f'ribbon_{sd}_0', f'ribbon_{sd}_1'], 'forearm_' + sd, 0.026, C_BODY, mass=0.3, tens=30.0, bend=0.1, air=1.2, dist=0.006, goal=0.0, pinw=lambda t: 1.0 if t == 0 else 0.0)
    strip('hair_' + sd, [f'hair_{sd}_0', f'hair_{sd}_1'], 'head', 0.014, C_BODY, mass=0.3, tens=40.0, bend=5.0, air=0.6, dist=0.004, goal=3.0, pinw=lambda t: 1.0 if t < 0.12 else 0.5 * (1 - t) ** 1.5 + 0.02)
for p in PIECES:
    o = p['ob']; vg = o.vertex_groups.new(name='pin')
    for i, w in p['pin'].items():
        if w > 0: vg.add([i], w, 'REPLACE')
    hk = o.modifiers.new('hook', 'HOOK'); hk.object = empty(p['bone']); hk.falloff_type = 'NONE'; hk.strength = 1.0; hk.vertex_indices_set(list(range(len(o.data.vertices))))
def add_cloth(p, n):
    o = p['ob']
    if 'cloth' in o.modifiers: o.modifiers.remove(o.modifiers['cloth'])
    md = o.modifiers.new('cloth', 'CLOTH'); s = md.settings; c = md.collision_settings
    s.quality = 16; s.mass = p['mass']; s.tension_stiffness = p['tens']; s.compression_stiffness = p['tens']; s.shear_stiffness = p['tens'] * 0.35; s.bending_stiffness = p['bend']
    s.tension_damping = 4; s.compression_damping = 4; s.shear_damping = 4; s.bending_damping = 0.4; s.air_damping = p['air']
    s.vertex_group_mass = 'pin'; s.pin_stiffness = max(p['goal'], 0.01)
    c.use_collision = True; c.collision_quality = 5; c.distance_min = p['dist']; c.collection = p['col']; c.use_self_collision = False; c.impulse_clamp = float(os.environ.get('CLAMP', 0.05)); c.collision_quality = 8
    md.point_cache.frame_start = 1; md.point_cache.frame_end = n
def key(e, loc, quat):
    """Location and rotation keys on frames 1..n, linear."""
    if e.animation_data and e.animation_data.action: bpy.data.actions.remove(e.animation_data.action)
    act = bpy.data.actions.new(e.name); n = len(loc); fr = np.arange(1, n + 1, dtype=float)
    for path, arr in (('location', loc), ('rotation_quaternion', quat)):
        for i in range(arr.shape[1]):
            fc = act.fcurves.new(path, index=i); fc.keyframe_points.add(n); fc.keyframe_points.foreach_set('co', np.stack([fr, arr[:, i]], 1).ravel())
            fc.keyframe_points.foreach_set('interpolation', [1] * n); fc.update()
    e.animation_data_create(); e.animation_data.action = act
    if hasattr(e.animation_data, 'action_slot') and e.animation_data.action_slot is None and len(act.slots): e.animation_data.action_slot = act.slots[0]
def lerp_rows(X, idx):
    i0 = np.clip(np.floor(idx).astype(int), 0, len(X) - 1); i1 = np.minimum(i0 + 1, len(X) - 1); f = (idx - i0).reshape((-1,) + (1,) * (X.ndim - 1)); return X[i0] * (1 - f) + X[i1] * f
if PREV:
    os.makedirs(PREV, exist_ok=True); sc.render.engine = 'BLENDER_WORKBENCH'; sc.display.shading.light = 'STUDIO'; sc.display.shading.color_type = 'OBJECT'; sc.render.resolution_x = 420; sc.render.resolution_y = 640
    cam = bpy.data.objects.new('cam', bpy.data.cameras.new('cam')); sc.collection.objects.link(cam); cam.data.type = 'ORTHO'; cam.data.ortho_scale = 2.0; sc.camera = cam
    gown.color = (0.15, 0.15, 0.2, 1)
    for o in C_LEGS.objects: o.color = (0.9, 0.7, 0.6, 1)
    web.hide_render = True
    for o in C_BODY.objects: o.color = (0.6, 0.8, 0.9, 1); o.display_type = 'WIRE'; o.hide_render = True
    for o, _, _ in STRIPS: o.color = (0.7, 0.1, 0.1, 1)
bpy.ops.object.effector_add(type='WIND'); wind = bpy.context.object; wind.field.flow = 0.0; wind.rotation_euler = (-math.pi / 2, 0, 0)      # blows along +Y: from her front to her back
WIND = float(os.environ.get('WIND', 0))
RAMP = 30
out = {}; bake_bones = [int(b) for b in CR.chain.ravel()] + [b for _, bs, _ in STRIPS for b in bs]; out['bones'] = np.array([rig.names[b] for b in bake_bones])
names = sorted({k.split('/')[0] for k in body.files})
for name in names:
    if ONLY and name not in ONLY: continue
    t0 = time.time(); local = body[name + '/local']; pel = body[name + '/pelvis']; fps, loop, speed, sig = body[name + '/meta']; loop = bool(loop); yk = body[name + '/yaw']
    F = len(local) - (1 if loop else 0); wr, wp = rig.fk(local, pel)
    if loop:
        T = F / fps; cycles = max(2, int(math.ceil(2.4 / T)) + 1); n = RAMP + int(round(cycles * T * FPS)) + 1; tt = np.maximum(np.arange(n) - RAMP, 0) / FPS; u = (tt % T) * fps; start = RAMP + (cycles - 1) * T * FPS
    else:
        pre = RAMP + 30; n = pre + int(round((F - 1) / fps * FPS)) + 1; tt = np.maximum(np.arange(n) - pre, 0) / FPS; u = tt * fps; start = pre
    ease = np.clip(np.arange(n) / RAMP, 0, 1); ease = (ease * ease * (3 - 2 * ease))[:, None]      # the body moves from the rest pose (the cloth's own shape) into the clip's first pose
    yaw = np.radians(np.interp(tt, yk[:, 0], yk[:, 1])); qy = axis_angle(np.array([0, 1.0, 0]), yaw); travel = np.zeros((n, 3)); wind.field.strength = WIND * speed      # simulated in the character's frame: the air she walks through is a head wind
    for bone, e in EMP.items():
        b = rig.index[bone]; q = qmul(wr[:, b], qinv(rig.rest_wr[b])[None]); q[1:] *= np.cumprod(np.where(np.sum(q[1:] * q[:-1], -1) < 0, -1.0, 1.0))[:, None]
        t = wp[:, b] - qrot(q, rig.rest_wp[b]); q = qnorm(lerp_rows(q, u)); t = lerp_rows(t, u)
        q = qnorm(q * ease + np.array([0, 0, 0, 1.0]) * (1 - ease) * np.sign(q[:, 3:4] + 1e-12)); t = t * ease
        q = qmul(qy, q); t = qrot(qy, t) + travel; q[1:] *= np.cumprod(np.where(np.sum(q[1:] * q[:-1], -1) < 0, -1.0, 1.0))[:, None]
        key(e, g2b(t), np.stack([q[:, 3], q[:, 0], -q[:, 2], q[:, 1]], 1))
    for p in PIECES: add_cloth(p, n)
    sc.frame_start = 1; sc.frame_end = n; X = {p['ob'].name: np.zeros((n, len(p['ob'].data.vertices), 3)) for p in PIECES}
    for f in range(1, n + 1):
        sc.frame_set(f); dg = bpy.context.evaluated_depsgraph_get()
        for p in PIECES:
            buf = np.empty(len(p['ob'].data.vertices) * 3); p['ob'].evaluated_get(dg).data.vertices.foreach_get('co', buf); X[p['ob'].name][f - 1] = buf.reshape(-1, 3)
        if PREV and f - 1 >= start and int(f - 1 - start) % max(1, int((n - start) // 6)) == 0:
            c = np.array([0, 0, 0.95]); az = math.radians(35) + yaw[f - 1]
            cam.location = (c[0] + 6 * math.sin(az), c[1] - 6 * math.cos(az), c[2] + 0.6); cam.rotation_euler = (math.radians(84.3), 0, az); sc.render.filepath = '%s/%s_%03d.png' % (PREV, name, f - 1 - int(start)); bpy.ops.render.render(write_still=True)
    # back to the character's frame, the clip's own frames, loops closed
    k = np.arange(F) / fps * FPS + start; res = {}
    for nm, x in X.items():
        x = qrot(qinv(qy)[:, None], b2g(x) - travel[:, None]); y = lerp_rows(x, k)
        if loop:
            diff = lerp_rows(x, np.array([start + F / fps * FPS]))[0] - y[0]; y = y - diff[None] * (np.arange(F) / F - 0.5)[:, None, None]
            res[nm + '_gap'] = float(np.linalg.norm(diff, axis=-1).max())
        res[nm] = y
    fit = local[:F].copy(); N = res['gown'].reshape(F, R_, C_, 3)[:, CR.rows][:, :, CR.cols].transpose(0, 2, 1, 3)
    raw = min(float((np.linalg.norm(res['gown'] - (a_[:, None] + np.clip(np.sum((res['gown'] - a_[:, None]) * (b_ - a_)[:, None], -1) / np.sum((b_ - a_) ** 2, -1)[:, None], 0, 1)[..., None] * (b_ - a_)[:, None]), axis=-1)).min()) - max(r0, r1)
              for _, a_, b_, r0, r1 in CR.capsules(*rig.fk(fit, pel[:F])))
    CR.resolve(fit, pel[:F], N, loop=loop, log=print)
    for o, bones, rows in STRIPS: SK.fit_chain(rig, fit, pel[:F], bones, res[o.name][:, rows])
    dmin, who = CR.distance(fit, pel[:F]); ins = CR.inside(fit, pel[:F])
    q = fit[:, bake_bones]; out[name + '/q'] = np.concatenate([q, q[:1]]).astype(np.float32) if loop else q.astype(np.float32); out[name + '/sig'] = sig
    print('BAKE %-12s frames %3d sim %4d  %.0f s  loop gap %.3f  cloth-to-capsule (coarse) %.3f  skinned min %.4f (%s)  leg inside %s' % (name, F, n, time.time() - t0, res.get('gown_gap', 0), raw, dmin.min(), who[int(dmin.argmin())], bool(ins.all())), flush=True)
    np.savez_compressed(OUT, **out)
print('BAKE DONE', OUT)
