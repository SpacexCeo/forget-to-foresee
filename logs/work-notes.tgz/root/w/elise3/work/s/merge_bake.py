"""Merges freshly baked clips into the cloth bake file (a partial bake keeps the other clips).
    python3 merge_bake.py <elise_cloth.npz> <new.npz>"""
import os, sys
import numpy as np
dst, new = sys.argv[1:3]; out = dict(np.load(dst)) if os.path.exists(dst) else {}; n = np.load(new)
if 'bones' in out and list(out['bones']) != list(n['bones']): out = {}
out.update({k: n[k] for k in n.files}); np.savez_compressed(dst, **out); print('bake file', dst, sorted({k.split('/')[0] for k in out if '/' in k}))
