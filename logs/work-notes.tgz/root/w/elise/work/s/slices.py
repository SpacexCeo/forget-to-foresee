import numpy as np, trimesh
from PIL import Image
B = trimesh.load('a1_body.ply', process=False); V = np.asarray(B.vertices); C = np.load('vc_body.npy')
ims = []
for z in (0.06, 0.15, 0.3, 0.45, 0.6, 0.72, 0.85):
    m = (abs(V[:, 2] - z) < 0.004) & (abs(V[:, 0]) < 0.3)
    im = np.full((400, 560, 3), 255, np.uint8)
    u = np.clip(((V[m, 0] + 0.28) / 0.56 * 560).astype(int), 0, 559); v = np.clip(((V[m, 1] + 0.2) / 0.4 * 400).astype(int), 0, 399)
    c = (np.clip(C[m], 0, 1) * 255).astype(np.uint8)
    for du in (0, 1):
        for dv in (0, 1): im[np.clip(v + dv, 0, 399), np.clip(u + du, 0, 559)] = c
    im[::100, :, :] = im[::100, :, :] // 2 + 100; im[:, ::100, :] = im[:, ::100, :] // 2 + 100   # grid every 10 cm; x=-0.28 left, y=-0.2 (front) top
    ims.append(im)
Image.fromarray(np.concatenate([np.concatenate(ims[:4], 1), np.concatenate(ims[4:] + [np.full((400, 560, 3), 255, np.uint8)], 1)], 0)).save('r/slices.png')
