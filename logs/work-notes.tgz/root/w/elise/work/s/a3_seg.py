import numpy as np, trimesh, sys
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
thr = float(sys.argv[1]) if len(sys.argv) > 1 else 30
B = trimesh.load('a1_body.ply', process=False); V = np.asarray(B.vertices); F = np.asarray(B.faces); C = np.load('vc_body.npy')
adj = B.face_adjacency; ang = np.degrees(B.face_adjacency_angles); conv = B.face_adjacency_convex
fz = V[F][:, :, 2].max(1); fx = abs(V[F][:, :, 0]).max(1)
bar = np.zeros(len(F), bool); e = adj[(~conv) & (ang > thr)]; bar[e.ravel()] = True
bar |= (fz > 0.80) | (fx > 0.215)
ok = ~bar[adj].any(1); g = coo_matrix((np.ones(ok.sum()), (adj[ok, 0], adj[ok, 1])), shape=(len(F), len(F)))
lab = connected_components(g, directed=False)[1]; lab[bar] = -1
seen = ~((C[:, 0] > 0.98) & (C[:, 1] < 0.02)); st = seen & (V[:, 0] > 0) & (V[:, 2] > 0.1) & (V[:, 2] < 0.7) & (C.max(1) > 0.26) & (C[:, 0] >= C[:, 2])
fst = st[F].all(1)
ids, cnt = np.unique(lab[lab >= 0], return_counts=True); order = np.argsort(-cnt)[:14]
col = np.full((len(F), 3), 90, np.uint8); pal = np.random.default_rng(3).integers(60, 255, (14, 3))
for k, o in enumerate(order):
    m = lab == ids[o]; p = V[F[m]].reshape(-1, 3)
    print(k, 'faces', cnt[o], 'stock', int((fst & m).sum()), 'lo', p.min(0).round(2), 'hi', p.max(0).round(2)); col[m] = pal[k]
col[bar] = (0, 0, 0)
np.save('seg_lab.npy', lab)
trimesh.Trimesh(V[F].reshape(-1, 3), np.arange(len(F) * 3).reshape(-1, 3), vertex_colors=np.repeat(col, 3, 0), process=False).export('seg.ply')
