import bpy, sys, numpy as np
a = sys.argv[sys.argv.index("--") + 1:]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=a[0])
o=[o for o in bpy.context.scene.objects if o.type=='MESH'][0]
n=len(o.data.vertices); co=np.empty(n*3); o.data.vertices.foreach_get('co',co); co=co.reshape(-1,3)
M=np.array(o.matrix_world); co=co@M[:3,:3].T+M[:3,3]
print('verts',n,'faces',len(o.data.polygons),'lo',co.min(0).round(3),'hi',co.max(0).round(3))
nb=int(a[1]); z0,z1=co[:,2].min(),co[:,2].max()
for i in range(nb-1,-1,-1):
    lo=z0+(z1-z0)*i/nb; hi=z0+(z1-z0)*(i+1)/nb
    s=co[(co[:,2]>=lo)&(co[:,2]<hi)]
    if len(s)==0: continue
    h,e=np.histogram(s[:,0],bins=80,range=(co[:,0].min(),co[:,0].max()))
    occ=h>0; segs=[]; st=None
    for k,v in enumerate(occ):
        if v and st is None: st=k
        if (not v or k==len(occ)-1) and st is not None:
            segs.append((round(e[st],2),round(e[k if not v else k+1],2))); st=None
    print('z %.3f x%s y[%.2f %.2f] n%d'%((lo+hi)/2,segs,s[:,1].min(),s[:,1].max(),len(s)))
