import sys
from PIL import Image
ims=[Image.open(p).convert("RGBA") for p in sys.argv[2:]]
h=min(i.height for i in ims); ims=[i.resize((round(i.width*h/i.height),h)) for i in ims]
W=Image.new("RGB",(sum(i.width for i in ims),h),(235,235,238)); x=0
for i in ims: W.paste(i,(x,0),i); x+=i.width
if W.width>1800: W=W.resize((1800,round(W.height*1800/W.width)))
W.save(sys.argv[1],quality=88)
