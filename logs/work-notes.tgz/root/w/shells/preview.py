import bpy, sys, math
from mathutils import Vector
a = sys.argv[sys.argv.index("--") + 1:]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=a[0])
for o in list(bpy.data.objects):
    if o.name.endswith("_col"): bpy.data.objects.remove(o)
sc = bpy.context.scene
w = bpy.data.worlds.new("w"); sc.world = w; w.use_nodes = True
bg = w.node_tree.nodes["Background"]; sky = w.node_tree.nodes.new("ShaderNodeTexSky"); sky.sky_type = "NISHITA"; sky.sun_elevation = math.radians(28); sky.sun_rotation = math.radians(140)
w.node_tree.links.new(sky.outputs[0], bg.inputs[0]); bg.inputs[1].default_value = 0.35
sc.render.engine = "CYCLES"; sc.cycles.device = "GPU"; sc.cycles.samples = 48
p = bpy.context.preferences.addons["cycles"].preferences; p.compute_device_type = "OPTIX"; p.get_devices()
for d in p.devices: d.use = True
sc.render.resolution_x, sc.render.resolution_y = int(a[2]), int(a[3])
sc.view_settings.view_transform = "AgX"
cam = bpy.data.objects.new("c", bpy.data.cameras.new("c")); sc.collection.objects.link(cam); sc.camera = cam
cam.data.lens = float(a[7]) if len(a) > 7 else 50
loc = Vector((float(a[4]), float(a[5]), float(a[6]))); tgt = Vector((0, 0, float(a[8]) if len(a) > 8 else 9))
cam.location = loc; cam.rotation_euler = (tgt - loc).to_track_quat("-Z", "Y").to_euler()
sc.render.filepath = a[1]; bpy.ops.render.render(write_still=True)
